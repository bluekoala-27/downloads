// background.js
chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.id) return;

  try {
    await chrome.tabs.sendMessage(tab.id, { type: 'FAKE_TOGGLE_MENU' });
  } catch (e) {
    // Content scripts not present (page loaded before install/update).
    // Inject main first, then bridge, then try again.
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['content-main.js'],
        world: 'MAIN'
      });
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['content-bridge.js'],
        world: 'ISOLATED'
      });
      await new Promise(r => setTimeout(r, 50));
      await chrome.tabs.sendMessage(tab.id, { type: 'FAKE_TOGGLE_MENU' });
    } catch (err) {
      console.error('Fake mode: could not inject scripts.', err);
    }
  }
});