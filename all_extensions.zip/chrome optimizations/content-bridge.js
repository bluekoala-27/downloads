// content-bridge.js
(function () {
  'use strict';
  if (window.__fakeBridgeInstalled) return;
  window.__fakeBridgeInstalled = true;

  const BRIDGE_SOURCE = 'fake-extension-bridge';
  const MAIN_SOURCE = 'fake-extension-main';
  const SITE_KEY = 'fakeMode:' + location.origin;

  function sendToMain(type, payload = {}) {
    window.postMessage({ source: BRIDGE_SOURCE, type, ...payload }, '*');
  }

  function loadSavedMode() {
    chrome.storage.local.get([SITE_KEY], (result) => {
      const mode = result[SITE_KEY] || null;
      sendToMain('APPLY_MODE', { mode });
    });
  }

  window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.source !== MAIN_SOURCE) return;

    if (data.type === 'MAIN_READY') {
      loadSavedMode();
    } else if (data.type === 'SAVE_MODE') {
      chrome.storage.local.set({ [SITE_KEY]: data.mode });
    } else if (data.type === 'CLEAR_MODE') {
      chrome.storage.local.remove(SITE_KEY);
    }
  });

  chrome.runtime.onMessage.addListener((message) => {
    if (message && message.type === 'FAKE_TOGGLE_MENU') {
      sendToMain('TOGGLE_MENU');
    }
  });

  sendToMain('BRIDGE_READY');
})();