// content-main.js
(function () {
  'use strict';

  if (window.__fakeModeInstalled) return;
  window.__fakeModeInstalled = true;

  const BRIDGE_SOURCE = 'fake-extension-bridge';
  const MAIN_SOURCE = 'fake-extension-main';

  let overlayEl = null;
  let menuEl = null;
  let iconContainer = null;
  let messageEl = null;
  let styleEl = null;
  let activeMode = null;
  let isLocked = false;
  let domReady = false;
  let pendingAction = null;

  let savedBodyOverflow = '';
  let savedHtmlOverflow = '';
  let savedUserSelect = '';

  function lockPage() {
    if (isLocked) return;
    savedBodyOverflow = document.body.style.overflow;
    savedHtmlOverflow = document.documentElement.style.overflow;
    savedUserSelect = document.body.style.userSelect;
    document.body.style.overflow = 'hidden';
    document.documentElement.style.overflow = 'hidden';
    document.body.style.userSelect = 'none';
    isLocked = true;
  }

  function unlockPage() {
    if (!isLocked) return;
    document.body.style.overflow = savedBodyOverflow;
    document.documentElement.style.overflow = savedHtmlOverflow;
    document.body.style.userSelect = savedUserSelect;
    isLocked = false;
  }

  function blockKey(e) {
    if (!isLocked) return;
    const keys = [
      'Tab', 'Enter', ' ', 'Space', 'ArrowUp', 'ArrowDown',
      'ArrowLeft', 'ArrowRight', 'Escape', 'PageUp', 'PageDown',
      'Home', 'End'
    ];
    if (keys.includes(e.key) || e.code === 'Space') {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
    }
  }

  function onKeyDown(e) {
    if (e.key === 'Escape') {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
      turnOff();
      return;
    }
    blockKey(e);
  }

  function onKeyUp(e) { blockKey(e); }
  function onKeyPress(e) { blockKey(e); }

  const MODES = {
    loading: {
      overlayBg: 'rgba(128,128,128,0.6)',
      cursor: 'wait',
      icon: () => {
        const el = document.createElement('div');
        el.style.cssText =
          'width:50px;height:50px;border:5px solid rgba(255,255,255,0.3);border-top:5px solid #fff;border-radius:50%;animation:fake-spin 1s linear infinite;box-shadow:0 2px 8px rgba(0,0,0,0.2);';
        return el;
      },
      message: 'Loading...',
      messageStyle: { color: '#fff' }
    },
    error: {
      overlayBg: '#b91c1c',
      cursor: 'not-allowed',
      icon: () => {
        const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        svg.setAttribute('width', '60');
        svg.setAttribute('height', '60');
        svg.setAttribute('viewBox', '0 0 24 24');
        svg.setAttribute('fill', 'none');
        svg.setAttribute('stroke', '#fff');
        svg.setAttribute('stroke-width', '2');
        svg.setAttribute('stroke-linecap', 'round');
        svg.setAttribute('stroke-linejoin', 'round');
        const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        circle.setAttribute('cx', '12');
        circle.setAttribute('cy', '12');
        circle.setAttribute('r', '10');
        const line1 = document.createElementNS('http://www.w3.org/2000/svg', 'line');
        line1.setAttribute('x1', '12');
        line1.setAttribute('y1', '8');
        line1.setAttribute('x2', '12');
        line1.setAttribute('y2', '12');
        const line2 = document.createElementNS('http://www.w3.org/2000/svg', 'line');
        line2.setAttribute('x1', '12');
        line2.setAttribute('y1', '16');
        line2.setAttribute('x2', '12.01');
        line2.setAttribute('y2', '16');
        svg.appendChild(circle);
        svg.appendChild(line1);
        svg.appendChild(line2);
        return svg;
      },
      message: 'An unexpected error occurred',
      messageStyle: { color: '#fff', fontSize: '24px' }
    },
    timeout: {
      overlayBg: '#b45309',
      cursor: 'not-allowed',
      icon: () => {
        const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        svg.setAttribute('width', '60');
        svg.setAttribute('height', '60');
        svg.setAttribute('viewBox', '0 0 24 24');
        svg.setAttribute('fill', 'none');
        svg.setAttribute('stroke', '#fff');
        svg.setAttribute('stroke-width', '2');
        svg.setAttribute('stroke-linecap', 'round');
        svg.setAttribute('stroke-linejoin', 'round');
        const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        circle.setAttribute('cx', '12');
        circle.setAttribute('cy', '12');
        circle.setAttribute('r', '10');
        const polyline = document.createElementNS('http://www.w3.org/2000/svg', 'polyline');
        polyline.setAttribute('points', '12 6 12 12 16 14');
        svg.appendChild(circle);
        svg.appendChild(polyline);
        return svg;
      },
      message: 'Request Timeout (404)',
      messageStyle: { color: '#fff', fontSize: '24px' }
    }
  };

  function ensureDom() {
    if (!document.body) return false;
    if (overlayEl && menuEl && styleEl) return true;

    styleEl = document.createElement('style');
    styleEl.textContent = '@keyframes fake-spin{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}';
    (document.head || document.documentElement).appendChild(styleEl);

    menuEl = document.createElement('div');
    menuEl.id = 'fake-mode-menu';
    menuEl.style.cssText =
      'position:fixed;bottom:20px;right:20px;background:rgba(0,0,0,0.6);backdrop-filter:blur(4px);padding:8px;border-radius:8px;display:flex;gap:8px;z-index:2147483647;border:1px solid rgba(255,255,255,0.2);box-shadow:0 4px 12px rgba(0,0,0,0.3);';

    const makeButton = (label, mode) => {
      const btn = document.createElement('button');
      btn.textContent = label;
      btn.style.cssText =
        'padding:6px 12px;border:none;border-radius:4px;font-size:13px;font-weight:bold;cursor:pointer;background:#fff;color:#333;transition:background 0.15s;border:1px solid rgba(255,255,255,0.3);';
      btn.addEventListener('mouseenter', () => btn.style.background = '#e0e0e0');
      btn.addEventListener('mouseleave', () => btn.style.background = '#fff');
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        if (mode === 'off') {
          turnOff();
        } else {
          setMode(mode, true);
        }
      });
      return btn;
    };

    menuEl.appendChild(makeButton('Loading', 'loading'));
    menuEl.appendChild(makeButton('Error', 'error'));
    menuEl.appendChild(makeButton('Timeout 404', 'timeout'));
    menuEl.appendChild(makeButton('Off', 'off'));
    document.body.appendChild(menuEl);

    overlayEl = document.createElement('div');
    overlayEl.id = 'fake-loading-overlay';
    overlayEl.style.cssText =
      'position:fixed;top:0;left:0;width:100vw;height:100vh;z-index:2147483646;display:none;flex-direction:column;align-items:center;justify-content:center;pointer-events:auto;backdrop-filter:blur(2px);';

    iconContainer = document.createElement('div');
    iconContainer.style.cssText =
      'display:flex;justify-content:center;align-items:center;min-height:80px;margin-bottom:20px;';

    messageEl = document.createElement('div');
    messageEl.style.cssText =
      'font-family:Arial,sans-serif;font-size:24px;font-weight:500;text-shadow:0 2px 8px rgba(0,0,0,0.3);text-align:center;padding:0 20px;';

    overlayEl.appendChild(iconContainer);
    overlayEl.appendChild(messageEl);
    document.body.appendChild(overlayEl);

    document.addEventListener('keydown', onKeyDown, { capture: true, passive: false });
    document.addEventListener('keyup', onKeyUp, { capture: true, passive: false });
    document.addEventListener('keypress', onKeyPress, { capture: true, passive: false });

    return true;
  }

  function setMode(mode, persist) {
    if (!domReady) {
      pendingAction = { type: 'setMode', mode, persist };
      return;
    }
    if (!ensureDom()) return;
    const config = MODES[mode];
    if (!config) return;

    activeMode = mode;
    lockPage();

    overlayEl.style.backgroundColor = config.overlayBg;
    overlayEl.style.cursor = config.cursor;
    overlayEl.style.display = 'flex';

    iconContainer.innerHTML = '';
    iconContainer.appendChild(config.icon());
    messageEl.textContent = config.message;
    Object.assign(messageEl.style, config.messageStyle);

    menuEl.style.display = 'none';

    if (persist) {
      window.postMessage({ source: MAIN_SOURCE, type: 'SAVE_MODE', mode }, '*');
    }
  }

  function turnOff() {
    if (!domReady) {
      pendingAction = { type: 'off' };
      return;
    }
    if (!overlayEl) return;
    activeMode = null;
    overlayEl.style.display = 'none';
    unlockPage();
    if (menuEl) menuEl.style.display = 'flex';
    window.postMessage({ source: MAIN_SOURCE, type: 'CLEAR_MODE' }, '*');
  }

  function toggleMenu() {
    if (!domReady) {
      pendingAction = { type: 'toggleMenu' };
      return;
    }
    if (!ensureDom()) return;
    if (menuEl.style.display === 'none' || menuEl.style.display === '') {
      menuEl.style.display = 'flex';
      if (overlayEl) overlayEl.style.display = 'none';
      unlockPage();
      activeMode = null;
    } else {
      menuEl.style.display = 'none';
    }
  }

  function onDomReady() {
    domReady = true;
    if (pendingAction) {
      const action = pendingAction;
      pendingAction = null;
      if (action.type === 'setMode') setMode(action.mode, action.persist);
      else if (action.type === 'off') turnOff();
      else if (action.type === 'toggleMenu') toggleMenu();
    }
  }

  if (document.body) {
    onDomReady();
  } else {
    document.addEventListener('DOMContentLoaded', onDomReady, { once: true });
  }

  window.fake = function (mode) {
    if (mode === 'menu') toggleMenu();
    else if (mode === 'off') turnOff();
    else setMode(mode, true);
  };

  window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.source !== BRIDGE_SOURCE) return;

    if (data.type === 'APPLY_MODE') {
      if (data.mode) setMode(data.mode, false);
      else turnOff();
    } else if (data.type === 'TOGGLE_MENU') {
      toggleMenu();
    } else if (data.type === 'BRIDGE_READY') {
      window.postMessage({ source: MAIN_SOURCE, type: 'MAIN_READY' }, '*');
    }
  });

  window.postMessage({ source: MAIN_SOURCE, type: 'MAIN_READY' }, '*');
})();