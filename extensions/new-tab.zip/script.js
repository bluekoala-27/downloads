/* ---------- Favicon helper ---------- */
function getFaviconUrl(url) {
  try {
    const domain = new URL(url).hostname;
    return `https://icons.duckduckgo.com/ip3/${domain}.ico`;
  } catch {
    return '';
  }
}

/* ---------- Default shortcuts ---------- */
const defaultShortcuts = [
  { name: 'DeepSeek', url: 'https://chat.deepseek.com', icon: getFaviconUrl('https://chat.deepseek.com') },
  { name: 'Google', url: 'https://google.com', icon: getFaviconUrl('https://google.com') },
  { name: 'YouTube', url: 'https://youtube.com', icon: getFaviconUrl('https://youtube.com') },
  { name: 'GitHub', url: 'https://github.com', icon: getFaviconUrl('https://github.com') },
  { name: 'Reddit', url: 'https://reddit.com', icon: getFaviconUrl('https://reddit.com') },
  { name: 'ChatGPT', url: 'https://chat.openai.com', icon: getFaviconUrl('https://chat.openai.com') },
  { name: 'Arch Wiki', url: 'https://wiki.archlinux.org', icon: getFaviconUrl('https://wiki.archlinux.org') },
];

// These two must ALWAYS exist – we enforce them in loadShortcuts()
const specialShortcuts = [
  { name: 'Terminal', url: '#terminal', icon: '__terminal__' },
  { name: 'Settings', url: '#settings', icon: '__settings__' }
];

let currentIconEditIndex = -1; // which shortcut's icon we're changing

function loadShortcuts() {
  const stored = localStorage.getItem('vibe-shortcuts');
  let shortcuts = [];
  if (stored) {
    try { shortcuts = JSON.parse(stored); } catch(e) {}
  }
  // If nothing stored, start with defaults + specials
  if (!shortcuts.length) {
    shortcuts = [...defaultShortcuts, ...specialShortcuts];
    saveShortcuts(shortcuts);
  } else {
    // Ensure special ones exist (if missing, append them)
    const hasTerminal = shortcuts.some(s => s.url === '#terminal');
    const hasSettings = shortcuts.some(s => s.url === '#settings');
    if (!hasTerminal) shortcuts.push(specialShortcuts[0]);
    if (!hasSettings) shortcuts.push(specialShortcuts[1]);
    // Also ensure no duplicates
    const seen = new Set();
    shortcuts = shortcuts.filter(s => {
      const key = s.url === '#terminal' ? 'terminal' : s.url === '#settings' ? 'settings' : s.name.toLowerCase();
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
    saveShortcuts(shortcuts);
  }
  return shortcuts;
}

function saveShortcuts(shortcuts) {
  localStorage.setItem('vibe-shortcuts', JSON.stringify(shortcuts));
}

/* ---------- Wallpaper & Theme ---------- */
function getWallpaper() { return localStorage.getItem('vibe-wallpaper') || 'gradient'; }
function setWallpaper(type, url='') {
  localStorage.setItem('vibe-wallpaper', type);
  if (type === 'custom') localStorage.setItem('vibe-wallpaper-url', url);
  applyWallpaper();
}
function applyWallpaper() {
  const type = getWallpaper();
  const body = document.body;
  body.classList.remove('wallpaper-gradient','wallpaper-solid','wallpaper-custom');
  body.classList.add('wallpaper-'+type);
  const bg = document.getElementById('wallpaperLayer');
  if (type === 'custom') {
    const url = localStorage.getItem('vibe-wallpaper-url') || '';
    bg.style.backgroundImage = url ? `url(${url})` : 'none';
    bg.style.backgroundSize = 'cover';
    bg.style.backgroundPosition = 'center';
  } else {
    bg.style.backgroundImage = '';
  }
}
function getTheme() { return localStorage.getItem('vibe-theme') || 'default'; }
function setTheme(theme) {
  localStorage.setItem('vibe-theme', theme);
  applyTheme();
}
function applyTheme() {
  const theme = getTheme();
  const root = document.documentElement;
  const themes = {
    default: { accent:'#7aa2f7','accent-hover':'#89b4fa','panel-bg':'rgba(20,20,30,0.75)','terminal-btn-bg':'rgba(122,162,247,0.2)','terminal-btn-border':'rgba(122,162,247,0.3)','text':'#c0caf5','text-muted':'#6c6f93','modal-bg':'#1e1e2e','modal-border':'#313244','terminal-bg':'rgba(10,10,20,0.96)','terminal-header':'#1e1e2e','settings-bg':'rgba(10,10,20,0.96)','settings-border':'#313244' },
    green: { accent:'#a6e3a1','accent-hover':'#c3f0c3','panel-bg':'rgba(20,30,20,0.75)','terminal-btn-bg':'rgba(166,227,161,0.2)','terminal-btn-border':'rgba(166,227,161,0.3)','text':'#c0caf5','text-muted':'#6c6f93','modal-bg':'#1e2e1e','modal-border':'#314431','terminal-bg':'rgba(10,20,10,0.96)','terminal-header':'#1e2e1e','settings-bg':'rgba(10,20,10,0.96)','settings-border':'#314431' },
    purple: { accent:'#c4a7e7','accent-hover':'#dcc8f0','panel-bg':'rgba(30,20,40,0.75)','terminal-btn-bg':'rgba(196,167,231,0.2)','terminal-btn-border':'rgba(196,167,231,0.3)','text':'#c0caf5','text-muted':'#6c6f93','modal-bg':'#2e1e3e','modal-border':'#443154','terminal-bg':'rgba(20,10,30,0.96)','terminal-header':'#2e1e3e','settings-bg':'rgba(20,10,30,0.96)','settings-border':'#443154' },
    orange: { accent:'#fab387','accent-hover':'#fcc8a0','panel-bg':'rgba(40,30,20,0.75)','terminal-btn-bg':'rgba(250,179,135,0.2)','terminal-btn-border':'rgba(250,179,135,0.3)','text':'#c0caf5','text-muted':'#6c6f93','modal-bg':'#2e2a1e','modal-border':'#544a31','terminal-bg':'rgba(30,20,10,0.96)','terminal-header':'#2e2a1e','settings-bg':'rgba(30,20,10,0.96)','settings-border':'#544a31' }
  };
  const t = themes[theme] || themes.default;
  for (const [k,v] of Object.entries(t)) root.style.setProperty('--'+k, v);
  document.querySelectorAll('.theme-btn').forEach(b => b.classList.toggle('active', b.dataset.theme === theme));
  document.querySelectorAll('.wp-btn').forEach(b => b.classList.toggle('active', b.dataset.wall === getWallpaper()));
}

/* ---------- Edit mode state ---------- */
let editMode = false;
const editToggle = document.getElementById('editModeToggle');
const desktopEl = document.getElementById('desktop');

function setEditMode(active) {
  editMode = active;
  if (active) {
    desktopEl.classList.add('edit-mode');
    editToggle.classList.add('active-edit');
    editToggle.textContent = 'Done';
  } else {
    desktopEl.classList.remove('edit-mode');
    editToggle.classList.remove('active-edit');
    editToggle.textContent = 'Edit';
  }
  renderDesktop();
}
editToggle.addEventListener('click', () => setEditMode(!editMode));

/* ---------- Render desktop ---------- */
let draggedItem = null;
let draggedIdx = -1;
let dragGhost = null;

function renderDesktop() {
  const grid = document.getElementById('shortcutsGrid');
  grid.innerHTML = '';
  const shortcuts = loadShortcuts();

  shortcuts.forEach((s, index) => {
    const div = document.createElement('div');
    div.className = 'shortcut';
    div.setAttribute('data-index', index);
    div.draggable = false;

    // Remove button (only for normal shortcuts, not specials)
    if (s.url !== '#terminal' && s.url !== '#settings') {
      const rmBtn = document.createElement('button');
      rmBtn.className = 'remove-btn';
      rmBtn.innerHTML = '✕';
      rmBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        if (!editMode) return;
        const currentShortcuts = loadShortcuts();
        currentShortcuts.splice(index, 1);
        saveShortcuts(currentShortcuts);
        renderDesktop();
      });
      div.appendChild(rmBtn);
    }

    // Icon & label
    if (s.url === '#terminal') {
      div.innerHTML += `<div class="icon-fallback">>_</div><div class="label">${s.name}</div>`;
    } else if (s.url === '#settings') {
      // Use an inline SVG gear with proper styling
      div.innerHTML += `
        <svg class="icon-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color: var(--accent); width: 32px; height: 32px; margin-bottom: 6px;">
          <circle cx="12" cy="12" r="3"/>
          <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>
        </svg>
        <div class="label">${s.name}</div>`;
    } else {
      const img = document.createElement('img');
      img.src = s.icon || getFaviconUrl(s.url);
      img.alt = s.name;
      img.onerror = () => {
        img.style.display = 'none';
        const fb = document.createElement('div');
        fb.className = 'icon-fallback';
        fb.textContent = s.name.charAt(0).toUpperCase();
        div.insertBefore(fb, div.firstChild);
      };
      div.appendChild(img);
      const label = document.createElement('div');
      label.className = 'label';
      label.textContent = s.name;
      div.appendChild(label);
    }

    // Click behaviour (non-edit mode)
    div.addEventListener('click', (e) => {
      if (editMode) return;
      if (s.url === '#terminal') toggleTerminal();
      else if (s.url === '#settings') toggleSettings();
      else window.location.href = s.url;
    });

    // Drag events (edit mode only)
    div.addEventListener('mousedown', (e) => {
      if (!editMode) return;
      if (e.target.classList.contains('remove-btn')) return;
      e.preventDefault();
      const idx = parseInt(div.getAttribute('data-index'));
      startDrag(div, idx, e.clientX, e.clientY);
    });

    grid.appendChild(div);
  });
}

/* ---------- Drag and drop (same as before) ---------- */
function startDrag(element, index, startX, startY) {
  const shortcuts = loadShortcuts();
  draggedItem = element;
  draggedIdx = index;
  element.classList.add('dragging');

  const ghost = element.cloneNode(true);
  ghost.style.position = 'fixed';
  ghost.style.left = startX - element.offsetWidth/2 + 'px';
  ghost.style.top = startY - element.offsetHeight/2 + 'px';
  ghost.style.zIndex = '9999';
  ghost.style.pointerEvents = 'none';
  ghost.style.opacity = '0.7';
  dragGhost = ghost;
  document.body.appendChild(ghost);

  function onMove(e) {
    if (!dragGhost) return;
    dragGhost.style.left = e.clientX - element.offsetWidth/2 + 'px';
    dragGhost.style.top = e.clientY - element.offsetHeight/2 + 'px';
  }

  function onUp(e) {
    document.removeEventListener('mousemove', onMove);
    document.removeEventListener('mouseup', onUp);
    if (dragGhost) {
      dragGhost.remove();
      dragGhost = null;
    }
    if (draggedItem) {
      draggedItem.classList.remove('dragging');
      const allShortcuts = document.querySelectorAll('.shortcut');
      let targetIdx = -1;
      let minDist = Infinity;
      allShortcuts.forEach((s, i) => {
        if (s === draggedItem) return;
        const rect = s.getBoundingClientRect();
        const cx = rect.left + rect.width/2;
        const cy = rect.top + rect.height/2;
        const dist = Math.hypot(e.clientX - cx, e.clientY - cy);
        if (dist < minDist) {
          minDist = dist;
          targetIdx = i;
        }
      });
      if (targetIdx !== -1 && targetIdx !== draggedIdx) {
        const shortcuts = loadShortcuts();
        const [moved] = shortcuts.splice(draggedIdx, 1);
        shortcuts.splice(targetIdx, 0, moved);
        saveShortcuts(shortcuts);
      }
      draggedItem = null;
      draggedIdx = -1;
      renderDesktop();
    }
  }

  document.addEventListener('mousemove', onMove);
  document.addEventListener('mouseup', onUp);
}

/* ---------- Add shortcut modal ---------- */
const modalOverlay = document.getElementById('modalOverlay');
const addBtn = document.getElementById('addShortcutBtn');
const modalCancel = document.getElementById('modalCancel');
const modalSave = document.getElementById('modalSave');
const newName = document.getElementById('newName');
const newUrl = document.getElementById('newUrl');

addBtn.addEventListener('click', () => { modalOverlay.classList.add('active'); newName.focus(); });
function closeModal() { modalOverlay.classList.remove('active'); newName.value=''; newUrl.value=''; }
modalCancel.addEventListener('click', closeModal);
modalOverlay.addEventListener('click', e => { if (e.target === modalOverlay) closeModal(); });
modalSave.addEventListener('click', () => {
  const name = newName.value.trim();
  let url = newUrl.value.trim();
  if (!name || !url) return;
  if (!/^https?:\/\//i.test(url)) url = 'https://' + url;
  const shortcuts = loadShortcuts();
  if (shortcuts.some(s => s.name.toLowerCase() === name.toLowerCase())) {
    alert('A shortcut with that name already exists.');
    return;
  }
  shortcuts.push({ name, url, icon: getFaviconUrl(url) });
  saveShortcuts(shortcuts);
  renderDesktop();
  closeModal();
});

/* ---------- Search bar ---------- */
document.getElementById('searchForm').addEventListener('submit', e => {
  e.preventDefault();
  const input = document.getElementById('searchInput').value.trim();
  if (!input) return;
  if (/^https?:\/\//i.test(input) || /^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(\/.*)?$/.test(input)) {
    let url = input;
    if (!/^https?:\/\//i.test(url)) url = 'https://' + url;
    window.location.href = url;
  } else {
    window.location.href = `https://noai.duckduckgo.com/?q=${encodeURIComponent(input)}`;
  }
});

/* ---------- Clock ---------- */
function updateClock() {
  const now = new Date();
  document.getElementById('clock').textContent = now.toLocaleTimeString([], { hour:'2-digit', minute:'2-digit' });
}
setInterval(updateClock, 1000);
updateClock();

/* ---------- Terminal ---------- */
const terminalWindow = document.getElementById('terminalWindow');
const terminalInput = document.getElementById('terminalInput');
const terminalOutput = document.getElementById('terminalOutput');
const terminalClose = document.getElementById('terminalClose');
const terminalMinimize = document.getElementById('terminalMinimize');
const panelTerminalBtn = document.getElementById('panelTerminalBtn');

function toggleTerminal() {
  terminalWindow.classList.toggle('active');
  if (terminalWindow.classList.contains('active')) terminalInput.focus();
}
terminalClose.addEventListener('click', () => terminalWindow.classList.remove('active'));
terminalMinimize.addEventListener('click', () => terminalWindow.classList.remove('active'));
panelTerminalBtn.addEventListener('click', toggleTerminal);
document.addEventListener('keydown', e => {
  if (e.ctrlKey && e.key === '`') { e.preventDefault(); toggleTerminal(); }
  if (e.key === 'Escape' && terminalWindow.classList.contains('active')) terminalWindow.classList.remove('active');
});
// Dragging terminal
let termDragging = false, termDX=0, termDY=0;
document.getElementById('terminalWindowHeader').addEventListener('mousedown', e => {
  if (e.target.tagName === 'BUTTON') return;
  termDragging = true;
  const rect = terminalWindow.getBoundingClientRect();
  termDX = e.clientX - rect.left;
  termDY = e.clientY - rect.top;
  terminalWindow.style.cursor = 'grabbing';
});
document.addEventListener('mousemove', e => {
  if (!termDragging) return;
  terminalWindow.style.left = (e.clientX - termDX) + 'px';
  terminalWindow.style.top = (e.clientY - termDY) + 'px';
  terminalWindow.style.transform = 'none';
});
document.addEventListener('mouseup', () => { termDragging=false; terminalWindow.style.cursor=''; });

const fortunes = ["You will have a pleasant coding session.","A package update will fix everything.","Beware of rm -rf. Safety first.","Today is a good day to sudo.","The answer is 42."];

function processCommand(cmd) {
  const shortcuts = loadShortcuts();
  const parts = cmd.trim().split(/\s+/);
  const command = parts[0].toLowerCase();
  let response = '';
  switch (command) {
    case 'help': response = `Vibe Linux Terminal - Commands:
  search <query>    Search DuckDuckGo
  open <name>       Open a shortcut
  add <name> <url>  Add a new shortcut
  remove <name>     Remove a shortcut
  apt install <name> <url>   Install (add) shortcut
  apt remove <name>          Remove shortcut
  apt list                   List all shortcuts
  neofetch          Show system info
  cowsay <msg>      The cow says
  fortune           Random wisdom
  clear             Clear terminal
  exit              Close terminal
Desktop shortcuts: ${shortcuts.map(s=>s.name).join(', ')}`; break;
    case 'search': if (parts.length>1) { window.location.href=`https://duckduckgo.com/?q=${encodeURIComponent(parts.slice(1).join(' '))}`; return; } else response='Usage: search <query>'; break;
    case 'open': {
      const name = parts.slice(1).join(' ');
      const found = shortcuts.find(s=>s.name.toLowerCase()===name.toLowerCase());
      if (found) { if (found.url==='#terminal') toggleTerminal(); else if (found.url==='#settings') toggleSettings(); else window.location.href=found.url; return; }
      else response=`"${name}" not found.`; break;
    }
    case 'add': {
      const name=parts[1]; let url=parts.slice(2).join(' ');
      if(!name||!url){ response='Usage: add <name> <url>'; break; }
      if(!/^https?:\/\//i.test(url)) url='https://'+url;
      shortcuts.push({name,url,icon:getFaviconUrl(url)}); saveShortcuts(shortcuts); renderDesktop(); response=`Added "${name}".`; break;
    }
    case 'remove': {
      const name=parts.slice(1).join(' '); const idx=shortcuts.findIndex(s=>s.name.toLowerCase()===name.toLowerCase());
      if(idx===-1) response=`"${name}" not found.`; else { shortcuts.splice(idx,1); saveShortcuts(shortcuts); renderDesktop(); response=`Removed "${name}".`; } break;
    }
    case 'apt':
      if(parts[1]==='install'&&parts[2]&&parts[3]){ const name=parts[2]; let url=parts.slice(3).join(' '); if(!/^https?:\/\//i.test(url)) url='https://'+url; shortcuts.push({name,url,icon:getFaviconUrl(url)}); saveShortcuts(shortcuts); renderDesktop(); response=`Package "${name}" installed.`; }
      else if(parts[1]==='remove'&&parts[2]){ const name=parts.slice(2).join(' '); const idx=shortcuts.findIndex(s=>s.name.toLowerCase()===name.toLowerCase()); if(idx!==-1){ shortcuts.splice(idx,1); saveShortcuts(shortcuts); renderDesktop(); response=`Package "${name}" removed.`; } else response=`Package not installed.`; }
      else if(parts[1]==='list') response='Installed:\n'+shortcuts.map(s=>`  ${s.name}  ${s.url}`).join('\n');
      else response='apt: install <name> <url>, remove <name>, list'; break;
    case 'neofetch':
  response = `
<pre style="line-height:1.2; color:#c0caf5; font-size:12px;">
<span style="color:#7aa2f7">      ::::::::::</span>                      <span style="color:#f9e2af">vibelinux</span>
<span style="color:#7aa2f7">    ::::::::::::::::::</span>                  <span style="color:#a6e3a1">-------------------</span>
<span style="color:#7aa2f7">  ::::::::::::::::::::::::</span>              <span style="color:#89b4fa">OS:</span> Vibe Linux 4.2
<span style="color:#7aa2f7"> :::::</span><span style="color:#c4a7e7">╱╱╱╱╱╱╱╱╱╱╱╱╱╱</span><span style="color:#7aa2f7">:::::</span>             <span style="color:#89b4fa">Kernel:</span> 6.6.0-vibe
<span style="color:#7aa2f7"> ::::</span><span style="color:#c4a7e7">╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱</span><span style="color:#7aa2f7">::::</span>            <span style="color:#89b4fa">Shell:</span> /bin/vibe
<span style="color:#7aa2f7"> ::::</span><span style="color:#c4a7e7">╱╱╱╱</span><span style="color:#f38ba8">┳┳┳┳┳┳┳</span><span style="color:#c4a7e7">╱╱╱╱</span><span style="color:#7aa2f7">::::</span>            <span style="color:#89b4fa">Uptime:</span> ${new Date().getHours()} hours
<span style="color:#7aa2f7"> ::::</span><span style="color:#c4a7e7">╱╱╱╱</span><span style="color:#f38ba8">┃</span><span style="color:#fab387">▲</span><span style="color:#f9e2af">▲</span><span style="color:#a6e3a1">▲</span><span style="color:#f9e2af">▲</span><span style="color:#fab387">▲</span><span style="color:#f38ba8">┃</span><span style="color:#c4a7e7">╱╱╱╱</span><span style="color:#7aa2f7">::::</span>            <span style="color:#89b4fa">Packages:</span> ${loadShortcuts().length} (vibe)
<span style="color:#7aa2f7"> ::::</span><span style="color:#c4a7e7">╱╱╱╱</span><span style="color:#f38ba8">┃</span><span style="color:#fab387">▼</span><span style="color:#f9e2af">▼</span><span style="color:#a6e3a1">▼</span><span style="color:#f9e2af">▼</span><span style="color:#fab387">▼</span><span style="color:#f38ba8">┃</span><span style="color:#c4a7e7">╱╱╱╱</span><span style="color:#7aa2f7">::::</span>            <span style="color:#89b4fa">Terminal:</span> vibeterm
<span style="color:#7aa2f7"> ::::</span><span style="color:#c4a7e7">╱╱╱╱</span><span style="color:#f38ba8">┳┳┳┳┳┳┳</span><span style="color:#c4a7e7">╱╱╱╱</span><span style="color:#7aa2f7">::::</span>            <span style="color:#89b4fa">Theme:</span> ${getTheme()}
<span style="color:#7aa2f7"> :::::</span><span style="color:#c4a7e7">╲╲╲╲╲╲╲╲╲╲╲╲╲╲</span><span style="color:#7aa2f7">:::::</span>             <span style="color:#a6e3a1">“vibe coding, always.”</span>
<span style="color:#7aa2f7">  ::::::::::::::::::::::::</span>
<span style="color:#7aa2f7">    ::::::::::::::::::</span>
<span style="color:#7aa2f7">      ::::::::::</span>
</pre>`;
  break;
    case 'cowsay': if(parts.length>1){ const msg=parts.slice(1).join(' '); response=` _________________________\n< ${msg} >\n -------------------------\n        \\   ^__^\n         \\  (oo)\\_______\n            (__)\\       )\\/\\\n                ||----w |\n                ||     ||`; } else response='Usage: cowsay <message>'; break;
    case 'fortune': response=fortunes[Math.floor(Math.random()*fortunes.length)]; break;
    case 'clear': terminalOutput.innerHTML=''; return;
    case 'exit': case 'close': terminalWindow.classList.remove('active'); return;
    default: response=`Command not found: ${command}. Type "help".`;
  }
  const div=document.createElement('div'); div.innerHTML=`<span class="prompt">$</span> ${cmd}\n${response}`; terminalOutput.appendChild(div); terminalOutput.scrollTop=terminalOutput.scrollHeight;
}
terminalInput.addEventListener('keydown', e => { if(e.key==='Enter'){ const cmd=terminalInput.value.trim(); if(cmd) processCommand(cmd); terminalInput.value=''; } });

/* ---------- Settings window ---------- */
const settingsWindow = document.getElementById('settingsWindow');
const settingsClose = document.getElementById('settingsClose');
function toggleSettings() {
  settingsWindow.classList.toggle('active');
  if (settingsWindow.classList.contains('active')) {
    document.querySelectorAll('.wp-btn').forEach(b => b.classList.toggle('active', b.dataset.wall === getWallpaper()));
    document.querySelectorAll('.theme-btn').forEach(b => b.classList.toggle('active', b.dataset.theme === getTheme()));
    document.getElementById('customUrlBox').style.display = getWallpaper() === 'custom' ? 'flex' : 'none';
    if (getWallpaper() === 'custom') {
      document.getElementById('wallpaperUrl').value = localStorage.getItem('vibe-wallpaper-url') || '';
    }
  }
}
settingsClose.addEventListener('click', () => settingsWindow.classList.remove('active'));

document.querySelectorAll('.wp-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const type = btn.dataset.wall;
    if (type === 'custom') {
      document.getElementById('customUrlBox').style.display = 'flex';
    } else {
      document.getElementById('customUrlBox').style.display = 'none';
      setWallpaper(type);
      applyWallpaper();
    }
  });
});
document.getElementById('applyWallpaperUrl').addEventListener('click', () => {
  const url = document.getElementById('wallpaperUrl').value.trim();
  if (url) {
    setWallpaper('custom', url);
    applyWallpaper();
  }
});
document.querySelectorAll('.theme-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    setTheme(btn.dataset.theme);
    applyTheme();
  });
});

// Dragging settings window
let settingsDragging=false, settingsDX=0, settingsDY=0;
document.getElementById('settingsWindowHeader').addEventListener('mousedown', e => {
  if (e.target.tagName === 'BUTTON') return;
  settingsDragging = true;
  const rect = settingsWindow.getBoundingClientRect();
  settingsDX = e.clientX - rect.left;
  settingsDY = e.clientY - rect.top;
  settingsWindow.style.cursor = 'grabbing';
});
document.addEventListener('mousemove', e => {
  if (!settingsDragging) return;
  settingsWindow.style.left = (e.clientX - settingsDX) + 'px';
  settingsWindow.style.top = (e.clientY - settingsDY) + 'px';
  settingsWindow.style.transform = 'none';
});
document.addEventListener('mouseup', () => { settingsDragging=false; settingsWindow.style.cursor=''; });

/* ---------- Init ---------- */
applyWallpaper();
applyTheme();
renderDesktop();

// Aggressively force focus onto the search input
function forceFocus() {
  const input = document.getElementById('searchInput');
  if (!input) return;
  input.focus();
  // Move cursor to end (in case there's existing text)
  input.setSelectionRange(input.value.length, input.value.length);
}

// Try multiple times over the first second to overcome Chrome's focus theft
setTimeout(forceFocus, 0);
setTimeout(forceFocus, 50);
setTimeout(forceFocus, 200);
setTimeout(forceFocus, 500);

// Also focus whenever the user clicks on the desktop (not on interactive elements)
document.addEventListener('click', (e) => {
  const tag = e.target.tagName.toLowerCase();
  if (tag === 'button' || tag === 'a' || tag === 'input' || tag === 'textarea' || e.target.closest('.shortcut')) return;
  forceFocus();
});

// If the window loses and regains focus (e.g. you alt-tab back), re-focus the search bar
window.addEventListener('focus', () => {
  setTimeout(forceFocus, 50);
});