# HCODX Project

Exported from HCODX — Full HTML Editor IDE with Live Preview.
https://hcodx.com/vs-editor

Open newtab.html in any browser.
