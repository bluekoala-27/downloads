// content.js
// Re-applies custom title/favicon whenever the site tries to overwrite them.

(function () {
  const hostname = location.hostname;
  if (!hostname) return;

  // Captured once, before we touch anything.
  let originalTitle = document.title;
  let originalIcons = Array.from(
    document.querySelectorAll('link[rel*="icon"]')
  ).map((link) => link.cloneNode(true));

  let currentRule = null;
  let observer = null;

  // ---------- Favicon helpers ----------

  function removeAllIcons() {
    document.querySelectorAll('link[rel*="icon"]').forEach((el) => el.remove());
  }

  function addIcon(url) {
    if (!url) return;
    const link = document.createElement('link');
    link.rel = 'icon';
    link.href = url;
    if (url.startsWith('data:image/png')) link.type = 'image/png';
    else if (url.startsWith('data:image/svg')) link.type = 'image/svg+xml';
    else if (url.endsWith('.svg')) link.type = 'image/svg+xml';
    else if (url.endsWith('.png')) link.type = 'image/png';
    else if (url.endsWith('.jpg') || url.endsWith('.jpeg')) link.type = 'image/jpeg';
    else if (url.endsWith('.gif')) link.type = 'image/gif';
    else if (url.endsWith('.ico')) link.type = 'image/x-icon';
    link.dataset.tfcApplied = '1';
    (document.head || document.documentElement).appendChild(link);
  }

  function applyFaviconOnce(url) {
    removeAllIcons();
    if (url) addIcon(url);
  }

  function restoreOriginalIcons() {
    removeAllIcons();
    originalIcons.forEach((icon) => {
      (document.head || document.documentElement).appendChild(icon.cloneNode(true));
    });
  }

  // Enforce our favicon without removing/adding repeatedly:
  // - keep our icon, update its href if needed
  // - remove any icon we didn't create
  // - add ours if it's gone
  function enforceFavicon(desired) {
    if (!desired) return;
    const icons = document.querySelectorAll('link[rel*="icon"]');
    let ours = null;
    icons.forEach((el) => {
      if (el.dataset && el.dataset.tfcApplied === '1') {
        ours = el;
      } else {
        el.remove();
      }
    });
    if (!ours) {
      addIcon(desired);
    } else if (ours.href !== desired) {
      ours.href = desired;
    }
  }

  // ---------- Apply a rule ----------

  function applyRule(rule) {
    currentRule = rule;

    const enabled = !!(rule && rule.enabled);
    const customTitle = enabled && rule.title ? rule.title : null;
    const customFavicon = enabled && rule.favicon ? rule.favicon : null;

    // Title
    const desiredTitle = customTitle || originalTitle;
    if (document.title !== desiredTitle) {
      document.title = desiredTitle;
    }

    // Favicon
    if (customFavicon) {
      applyFaviconOnce(customFavicon);
    } else {
      restoreOriginalIcons();
    }

    // Only observe if we have something to enforce.
    if (customTitle || customFavicon) {
      startObserver();
    } else {
      stopObserver();
    }
  }

  // ---------- Mutation observer ----------

  function hasIconRel(el) {
    if (!el || !el.getAttribute) return false;
    const rel = (el.getAttribute('rel') || '').toLowerCase();
    return rel.includes('icon');
  }

  function handleMutations(mutations) {
    if (!currentRule || !currentRule.enabled) return;

    const customTitle = currentRule.title || null;
    const customFavicon = currentRule.favicon || null;
    if (!customTitle && !customFavicon) return;

    let titleChanged = false;
    let iconChanged = false;

    for (const m of mutations) {
      if (m.type === 'characterData') {
        const p = m.target.parentElement;
        if (p && p.nodeName === 'TITLE') titleChanged = true;
      } else if (m.type === 'childList') {
        // document.title = X -> target is the <title> element
        if (m.target.nodeName === 'TITLE') titleChanged = true;

        // <head> or <html> changed (title or head added/removed)
        if (m.target.nodeName === 'HEAD' || m.target.nodeName === 'HTML') {
          for (const n of m.addedNodes) {
            if (n.nodeName === 'TITLE' || n.nodeName === 'HEAD') titleChanged = true;
            if (n.nodeName === 'HEAD') iconChanged = true;
          }
          for (const n of m.removedNodes) {
            if (n.nodeName === 'TITLE' || n.nodeName === 'HEAD') titleChanged = true;
            if (n.nodeName === 'HEAD') iconChanged = true;
          }
        }

        // <link> icons added/removed under <head>
        if (m.target.nodeName === 'HEAD') {
          for (const n of m.addedNodes) {
            if (n.nodeName === 'LINK' && hasIconRel(n)) iconChanged = true;
          }
          for (const n of m.removedNodes) {
            if (n.nodeName === 'LINK' && hasIconRel(n)) iconChanged = true;
          }
        }
      }
    }

    if (titleChanged && customTitle) {
      if (document.title !== customTitle) {
        document.title = customTitle;
      }
    }

    if (iconChanged && customFavicon) {
      enforceFavicon(customFavicon);
    }
  }

  function startObserver() {
    if (observer) return;
    observer = new MutationObserver(handleMutations);
    observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
      characterData: true,
    });
  }

  function stopObserver() {
    if (observer) {
      observer.disconnect();
      observer = null;
    }
  }

  // ---------- Load rule ----------

  function loadRule() {
    chrome.storage.local.get('siteRules', (data) => {
      const rules = data.siteRules || {};
      applyRule(rules[hostname]);
    });
  }

  // ---------- Messages from the popup ----------

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'applyRule') {
      applyRule({
        enabled: message.enabled,
        title: message.title,
        favicon: message.favicon,
      });
      sendResponse({ ok: true });
    } else if (message.type === 'revert') {
      currentRule = null;
      stopObserver();
      if (document.title !== originalTitle) document.title = originalTitle;
      restoreOriginalIcons();
      sendResponse({ ok: true });
    }
    return true;
  });

  // ---------- React to saved-rule changes from other tabs ----------

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (!changes.siteRules) return;

    const newRules = changes.siteRules.newValue || {};
    const newRule = newRules[hostname];
    if (JSON.stringify(newRule) !== JSON.stringify(currentRule)) {
      applyRule(newRule);
    }
  });

  // ---------- Initialize ----------

  function initialize() {
    originalTitle = document.title;
    originalIcons = Array.from(
      document.querySelectorAll('link[rel*="icon"]')
    ).map((link) => link.cloneNode(true));
    loadRule();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialize);
  } else {
    initialize();
  }
})();