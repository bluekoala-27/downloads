// popup.js

const $ = (sel) => document.querySelector(sel);

const PRESETS = {
  magister: {
    title: 'Agenda - Magister',
    favicon: 'https://frencken.magister.net/magister/assets/images/appicon-2.png',
  },
  gmail: {
    title: 'Inbox (1) - 14534@frencken.info - Mgr. Frencken College Mail',
    favicon: 'https://www.google.com/a/cpanel/frencken.info/images/favicon.ico',
  },
  classroom: {
    title: 'Home - Classroom',
    favicon: 'https://www.gstatic.com/classroom/logo_square_rounded.svg',
  },
  canva: {
    title: 'Home - Canva',
    favicon: 'https://static.canva.com/domain-assets/canva/static/images/favicon-1.ico',
  },
  documenten: {
    title: 'Google Docs',
    favicon: 'https://ssl.gstatic.com/docs/documents/images/docs-favicon-2026-v2.ico',
  },
};

// …rest of popup.js unchanged…

let currentHostname = '';
let currentTabId = null;
let savedRules = {};

// ---------- Storage helpers ----------

function getCurrentTab() {
  return new Promise((resolve) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => resolve(tabs[0]));
  });
}

function getHostname(url) {
  try { return new URL(url).hostname; } catch { return ''; }
}

function getRules() {
  return new Promise((resolve) => {
    chrome.storage.local.get('siteRules', (data) => resolve(data.siteRules || {}));
  });
}

function setRules(rules) {
  return new Promise((resolve) => {
    chrome.storage.local.set({ siteRules: rules }, resolve);
  });
}

function getAdvancedMode() {
  return new Promise((resolve) => {
    chrome.storage.local.get('advancedMode', (data) => resolve(!!data.advancedMode));
  });
}

function setAdvancedMode(mode) {
  return new Promise((resolve) => {
    chrome.storage.local.set({ advancedMode: !!mode }, resolve);
  });
}

function sendMessageToTab(tabId, message) {
  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, message, (response) => {
      if (chrome.runtime.lastError) {
        console.warn('Message failed:', chrome.runtime.lastError.message);
      }
      resolve(response);
    });
  });
}

// ---------- UI helpers ----------

function updatePreview() {
  const title = $('#title').value.trim() || 'Tab title';
  $('#title-preview').textContent = title;

  const faviconUrl = $('#favicon').value.trim();
  const img = $('#favicon-preview');
  if (faviconUrl) {
    img.src = faviconUrl;
    img.style.display = '';
  } else {
    img.removeAttribute('src');
    img.style.display = 'none';
  }
}

function showStatus(msg, isError = false, timeout = 2500) {
  const el = $('#status');
  el.textContent = msg;
  el.style.color = isError ? 'var(--danger)' : 'var(--primary)';
  if (timeout > 0) {
    setTimeout(() => {
      if (el.textContent === msg) el.textContent = '';
    }, timeout);
  }
}

// ---------- Advanced mode ----------

function applyAdvancedModeUI(enabled) {
  $('#advanced-toggle').checked = enabled;
  $('#advanced-tools').classList.toggle('hidden', !enabled);
}

async function handleAdvancedToggle() {
  const enabled = $('#advanced-toggle').checked;
  await setAdvancedMode(enabled);
  $('#advanced-tools').classList.toggle('hidden', !enabled);
  showStatus(enabled ? 'Advanced tools unlocked' : 'Advanced tools hidden');
}

// ---------- Presets ----------

function handlePresetChange() {
  const key = $('#preset').value;
  if (!key) return;
  const preset = PRESETS[key];
  if (!preset) return;

  $('#title').value = preset.title;
  $('#favicon').value = preset.favicon;
  updatePreview();
  showStatus('Preset applied');

  setTimeout(() => { $('#preset').value = ''; }, 100);
}

// ---------- URL parsing ----------

function normalizeSiteUrl(input) {
  const trimmed = input.trim();
  if (!trimmed) return null;
  const withScheme = /^[a-z][a-z0-9+.-]*:\/\//i.test(trimmed)
    ? trimmed
    : 'https://' + trimmed;
  try {
    const u = new URL(withScheme);
    if (!u.hostname) return null;
    return u;
  } catch { return null; }
}

function parseExactUrl(input) {
  try {
    const u = new URL(input.trim());
    if (!u.hostname) return null;
    return u;
  } catch { return null; }
}

// ---------- Favicon fetching ----------

async function fetchFaviconFromSite(input, { exact = false } = {}) {
  const parsed = exact ? parseExactUrl(input) : normalizeSiteUrl(input);
  if (!parsed) throw new Error('Invalid URL');

  let html = null;
  try {
    const res = await fetch(parsed.href, { credentials: 'omit', redirect: 'follow' });
    if (res.ok) {
      const ct = (res.headers.get('content-type') || '').toLowerCase();
      if (ct.startsWith('image/')) return parsed.href;
      if (ct.includes('html') || ct.includes('xml')) html = await res.text();
    }
  } catch (e) { console.warn('Fetch failed:', e); }

  if (html) {
    try {
      const doc = new DOMParser().parseFromString(html, 'text/html');
      const baseHref = doc.querySelector('base[href]')?.href || parsed.href;

      const links = Array.from(doc.querySelectorAll(
        'link[rel~="icon"], link[rel="shortcut icon"], ' +
        'link[rel="apple-touch-icon"], link[rel="apple-touch-icon-precomposed"]'
      ));

      const score = (link) => {
        const rel = (link.getAttribute('rel') || '').toLowerCase();
        const type = (link.getAttribute('type') || '').toLowerCase();
        const sizes = (link.getAttribute('sizes') || '').toLowerCase();
        const href = (link.getAttribute('href') || '').toLowerCase();
        let s = 0;
        if (rel.includes('apple-touch-icon')) s += 1000;
        if (type.includes('svg') || href.endsWith('.svg')) s += 500;
        const m = sizes.match(/(\d+)\s*x\s*(\d+)/);
        if (m) s += parseInt(m[1], 10);
        if (sizes === 'any') s += 400;
        return s;
      };

      links.sort((a, b) => score(b) - score(a));

      for (const link of links) {
        const href = link.getAttribute('href');
        if (!href) continue;
        try {
          const abs = new URL(href, baseHref).href;
          if (/^https?:|^data:/i.test(abs)) return abs;
        } catch { /* skip */ }
      }
    } catch (e) { console.warn('HTML parse failed:', e); }
  }

  if (!exact) {
    const icoUrl = parsed.origin + '/favicon.ico';
    try {
      const res = await fetch(icoUrl, { method: 'GET', credentials: 'omit' });
      if (res.ok) return icoUrl;
    } catch (e) { console.warn('favicon.ico check failed:', e); }
  }

  return null;
}

async function handleFetchNormal() {
  const input = $('#site-fetch').value.trim();
  if (!input) { showStatus('Enter a site first', true); return; }

  const btn = $('#fetch-favicon');
  btn.disabled = true;
  showStatus('Searching favicon…', false, 0);

  try {
    const url = await fetchFaviconFromSite(input, { exact: false });
    if (url) {
      $('#favicon').value = url;
      updatePreview();
      showStatus('Favicon found!');
    } else {
      showStatus('No favicon found for that site', true);
    }
  } catch (e) {
    console.error(e);
    showStatus('Could not fetch: ' + e.message, true);
  } finally {
    btn.disabled = false;
  }
}

async function handleFetchExact() {
  const input = $('#exact-fetch').value.trim();
  if (!input) { showStatus('Enter an exact URL first', true); return; }

  const btn = $('#fetch-exact');
  btn.disabled = true;
  showStatus('Fetching exact URL…', false, 0);

  try {
    const url = await fetchFaviconFromSite(input, { exact: true });
    if (url) {
      $('#favicon').value = url;
      updatePreview();
      showStatus('Favicon found!');
    } else {
      showStatus('Nothing usable at that exact URL', true);
    }
  } catch (e) {
    console.error(e);
    showStatus('Could not fetch: ' + e.message, true);
  } finally {
    btn.disabled = false;
  }
}

// ---------- Load current site ----------

async function loadCurrentSite() {
  const tab = await getCurrentTab();
  if (!tab) return;
  currentTabId = tab.id;
  currentHostname = getHostname(tab.url);
  $('#site').textContent = currentHostname || '(unknown)';
  if (currentHostname) $('#site-fetch').placeholder = currentHostname;

  savedRules = await getRules();
  const rule = savedRules[currentHostname] || { enabled: false, title: '', favicon: '' };

  $('#enabled').checked = rule.enabled;
  $('#title').value = rule.title || '';
  $('#favicon').value = rule.favicon || '';

  updatePreview();
  renderSavedSites();
}

// ---------- Saved sites list ----------

function renderSavedSites() {
  const list = $('#saved-list');
  const count = $('#saved-count');
  list.innerHTML = '';

  const hostnames = Object.keys(savedRules).sort();
  count.textContent = hostnames.length;

  if (hostnames.length === 0) {
    const li = document.createElement('li');
    li.textContent = 'No saved sites yet.';
    li.style.color = 'var(--text-muted)';
    li.style.fontSize = '11px';
    li.style.padding = '4px 0';
    list.appendChild(li);
    return;
  }

  hostnames.forEach((host) => {
    const li = document.createElement('li');

    const span = document.createElement('span');
    span.className = 'hostname';
    span.textContent = host;
    span.title = host;

    const btn = document.createElement('button');
    btn.className = 'remove';
    btn.textContent = '✕';
    btn.title = 'Delete rule for this site';
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      await deleteRuleForHost(host);
    });

    li.appendChild(span);
    li.appendChild(btn);
    list.appendChild(li);
  });
}

async function deleteRuleForHost(host) {
  savedRules = await getRules();
  if (!savedRules[host]) return;

  delete savedRules[host];
  await setRules(savedRules);

  if (host === currentHostname) {
    $('#enabled').checked = false;
    $('#title').value = '';
    $('#favicon').value = '';
    updatePreview();
    if (currentTabId) await sendMessageToTab(currentTabId, { type: 'revert' });
  }

  renderSavedSites();
  showStatus('Deleted rule for ' + host);
}

// ---------- Save / delete current rule ----------

async function saveCurrentRule() {
  if (!currentHostname) {
    showStatus('Cannot save: unknown hostname', true);
    return;
  }

  const enabled = $('#enabled').checked;
  const title = $('#title').value.trim();
  const favicon = $('#favicon').value.trim();

  savedRules = await getRules();
  savedRules[currentHostname] = { enabled, title, favicon };
  await setRules(savedRules);

  if (currentTabId) {
    await sendMessageToTab(currentTabId, { type: 'applyRule', enabled, title, favicon });
  }

  renderSavedSites();
  showStatus('Saved!');
}

async function deleteCurrentRule() {
  if (!currentHostname) return;

  savedRules = await getRules();
  if (!savedRules[currentHostname]) {
    showStatus('No rule to delete', true);
    return;
  }

  delete savedRules[currentHostname];
  await setRules(savedRules);

  $('#enabled').checked = false;
  $('#title').value = '';
  $('#favicon').value = '';
  updatePreview();

  if (currentTabId) await sendMessageToTab(currentTabId, { type: 'revert' });

  renderSavedSites();
  showStatus('Deleted!');
}

// ---------- Saved list toggle ----------

function toggleSavedList() {
  const list = $('#saved-list');
  const btn = $('#toggle-saved');
  const expanded = btn.getAttribute('aria-expanded') === 'true';
  btn.setAttribute('aria-expanded', String(!expanded));
  list.classList.toggle('hidden', expanded);
}

// ---------- Upload via separate popup window ----------
//
// Chrome closes the extension popup the moment the native file dialog
// opens, which destroys popup.js. So we open a tiny popup *window*
// (chrome.windows.create) that contains its own file input. When the
// user picks a file, that window saves the data URL to chrome.storage
// under `_pendingFavicon` and closes itself. We read it back here on
// next open, and live if the popup is still around.

function openFilePicker() {
  chrome.windows.create(
    {
      url: chrome.runtime.getURL('file-picker.html'),
      type: 'popup',
      width: 400,
      height: 220,
    },
    () => {
      if (chrome.runtime.lastError) {
        console.warn('Could not open file picker:', chrome.runtime.lastError.message);
        showStatus('Could not open file picker', true);
      }
    }
  );
}

function consumePendingFavicon(value, { silent = false } = {}) {
  $('#favicon').value = value;
  updatePreview();
  chrome.storage.local.remove('_pendingFavicon');
  if (!silent) showStatus('Custom image loaded');
}

function checkPendingFavicon() {
  chrome.storage.local.get('_pendingFavicon', (data) => {
    if (data._pendingFavicon) consumePendingFavicon(data._pendingFavicon);
  });
}

// ---------- Init ----------

document.addEventListener('DOMContentLoaded', async () => {
  await loadCurrentSite();
  applyAdvancedModeUI(await getAdvancedMode());
  checkPendingFavicon();

  // Live-update if the file picker writes while the popup is still open
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes._pendingFavicon &&
        changes._pendingFavicon.newValue) {
      consumePendingFavicon(changes._pendingFavicon.newValue);
    }
  });

  $('#enabled').addEventListener('change', updatePreview);
  $('#title').addEventListener('input', updatePreview);
  $('#favicon').addEventListener('input', updatePreview);

  $('#save').addEventListener('click', saveCurrentRule);
  $('#delete').addEventListener('click', deleteCurrentRule);
  $('#toggle-saved').addEventListener('click', toggleSavedList);

  $('#advanced-toggle').addEventListener('change', handleAdvancedToggle);
  $('#preset').addEventListener('change', handlePresetChange);

  $('#upload').addEventListener('click', openFilePicker);

  $('#fetch-favicon').addEventListener('click', handleFetchNormal);
  $('#site-fetch').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); handleFetchNormal(); }
  });

  $('#fetch-exact').addEventListener('click', handleFetchExact);
  $('#exact-fetch').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); handleFetchExact(); }
  });
});