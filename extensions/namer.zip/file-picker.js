// file-picker.js
// Runs inside the small popup window opened by chrome.windows.create.

const picker = document.getElementById('picker');
const status = document.getElementById('status');

picker.addEventListener('change', () => {
  const file = picker.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = (e) => {
    chrome.storage.local.set({ _pendingFavicon: e.target.result }, () => {
      status.textContent = 'Saved! Closing…';
      setTimeout(() => window.close(), 400);
    });
  };
  reader.readAsDataURL(file);
});

// Auto-open the file chooser as soon as this window finishes loading
window.addEventListener('load', () => {
  setTimeout(() => picker.click(), 100);
});