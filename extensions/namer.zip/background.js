// background.js
// The file input and its change handler live here, NOT in the popup.
// Chrome destroys popup JS when the popup loses focus (which happens
// when the OS file chooser opens). The background service worker
// survives, so it can handle the file after the user picks one.

let fileInput = null;

function getFileInput() {
  if (!fileInput) {
    fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = 'image/*';
    fileInput.addEventListener('change', handleFileSelected);
  }
  return fileInput;
}

function handleFileSelected(event) {
  const file = event.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = (ev) => {
    const dataUrl = ev.target.result;
    // Persist temporarily so the popup can read it when it reopens.
    // (The popup may have closed, so we can't just send a message back.)
    chrome.storage.local.set({ _pendingFavicon: dataUrl }, () => {
      console.log('Favicon data stored:', dataUrl.slice(0, 40) + '…');
    });
  };
  reader.readAsDataURL(file);
  event.target.value = '';
}

// Popup sends this message when the user clicks "Choose image…"
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'openFileChooser') {
    const input = getFileInput();
    input.click();
    sendResponse({ ok: true });
  }
  return true;
});