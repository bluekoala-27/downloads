(function() {
  // Schedule: [start, end] in minutes from midnight
  const SCHEDULE = [
    { start: 510, end: 555, label: 'Lesson 1', type: 'lesson' },
    { start: 555, end: 600, label: 'Lesson 2', type: 'lesson' },
    { start: 600, end: 615, label: 'Break', type: 'break' },
    { start: 620, end: 665, label: 'Lesson 3', type: 'lesson' },
    { start: 665, end: 710, label: 'Lesson 4', type: 'lesson' },
    { start: 710, end: 735, label: 'Break', type: 'break' },
    { start: 740, end: 785, label: 'Lesson 5', type: 'lesson' },
    { start: 785, end: 830, label: 'Lesson 6', type: 'lesson' },
    { start: 830, end: 875, label: 'Lesson 7', type: 'lesson' }
  ];

  // Convert schedule times to seconds from midnight for precision
  const SCHEDULE_SECONDS = SCHEDULE.map(item => ({
    ...item,
    startSec: item.start * 60,
    endSec: item.end * 60
  }));

  let container = null;
  let updateInterval = null;
  let currentSettings = {};

  // Default settings
  const defaultSettings = {
    primaryColor: '#4CAF50',
    bgCircleColor: '#e0e0e0',
    bgColor: '#ffffff',
    textColor: '#333333',
    headerText: 'Magister Clock',
    fontSize: 22,
    fontWeight: 700,
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif',
    sizeScale: 1.0
  };

  // Load settings from storage
  function loadSettings(callback) {
    chrome.storage.local.get(Object.keys(defaultSettings), (data) => {
      Object.keys(defaultSettings).forEach(key => {
        currentSettings[key] = data[key] !== undefined ? data[key] : defaultSettings[key];
      });
      if (callback) callback();
    });
  }

  // Get current time in seconds from midnight
  function getCurrentSeconds() {
    const now = new Date();
    return now.getHours() * 3600 + now.getMinutes() * 60 + now.getSeconds();
  }

  function getCurrentInterval() {
    const nowSec = getCurrentSeconds();
    const first = SCHEDULE_SECONDS[0];
    const last = SCHEDULE_SECONDS[SCHEDULE_SECONDS.length - 1];

    if (nowSec < first.startSec) {
      return {
        type: 'before',
        label: 'Not started',
        remainingSec: first.startSec - nowSec,
        progress: 0,
        start: first.start,
        end: first.start,
        isActive: false
      };
    }

    if (nowSec >= last.endSec) {
      return {
        type: 'after',
        label: 'Free',
        remainingSec: 0,
        progress: 1,
        start: last.end,
        end: last.end,
        isActive: false
      };
    }

    for (let i = 0; i < SCHEDULE_SECONDS.length; i++) {
      const interval = SCHEDULE_SECONDS[i];
      if (nowSec >= interval.startSec && nowSec < interval.endSec) {
        const totalSec = interval.endSec - interval.startSec;
        const elapsedSec = nowSec - interval.startSec;
        return {
          type: interval.type,
          label: interval.label,
          remainingSec: totalSec - elapsedSec,
          progress: elapsedSec / totalSec,
          start: interval.start,
          end: interval.end,
          isActive: true
        };
      }
    }
    return null;
  }

  function applySettings() {
    if (!container) return;
    container.style.backgroundColor = currentSettings.bgColor;
    container.style.transform = `scale(${currentSettings.sizeScale})`;
    container.style.transformOrigin = 'top left';
    container.style.fontFamily = currentSettings.fontFamily;

    const header = container.querySelector('#mc-header');
    if (header) {
      header.textContent = currentSettings.headerText;
      header.style.color = currentSettings.textColor;
    }

    const timeText = container.querySelector('#mc-time-text');
    if (timeText) {
      timeText.style.fill = currentSettings.textColor;
      timeText.style.fontSize = currentSettings.fontSize + 'px';
      timeText.style.fontWeight = currentSettings.fontWeight;
    }

    const label = container.querySelector('#mc-label');
    if (label) {
      label.style.color = currentSettings.textColor;
    }

    const bgCircle = container.querySelector('#mc-circle-bg');
    if (bgCircle) {
      bgCircle.style.stroke = currentSettings.bgCircleColor;
    }
  }

  function formatTime(seconds) {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  }

  function formatClockTime(minutes) {
    const h = Math.floor(minutes / 60);
    const m = minutes % 60;
    return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
  }

  function updateDisplay() {
    if (!container) return;
    const interval = getCurrentInterval();
    if (!interval) return;

    const bgCircle = document.getElementById('mc-circle-bg');
    const progressCircle = document.getElementById('mc-circle-progress');
    const timeText = document.getElementById('mc-time-text');
    const label = document.getElementById('mc-label');

    if (!bgCircle || !progressCircle || !timeText || !label) return;

    let remainingSec = 0;
    let progress = 0;
    let labelText = '';

    if (interval.type === 'before') {
      remainingSec = interval.remainingSec;
      progress = 0;
      labelText = `Starts at ${formatClockTime(interval.start)}`;
      progressCircle.style.stroke = '#2196F3';
    } else if (interval.type === 'after') {
      remainingSec = 0;
      progress = 1;
      labelText = 'Free';
      progressCircle.style.stroke = '#9E9E9E';
    } else {
      remainingSec = interval.remainingSec;
      progress = interval.progress;
      labelText = interval.label + ` (${formatClockTime(interval.start)}-${formatClockTime(interval.end)})`;
      progressCircle.style.stroke = currentSettings.primaryColor;
    }

    const circumference = 2 * Math.PI * 50;
    progressCircle.style.strokeDasharray = circumference;
    progressCircle.style.strokeDashoffset = circumference * (1 - progress);

    timeText.textContent = formatTime(remainingSec);
    label.textContent = labelText;

    applySettings();
  }

  function makeDraggable() {
    if (!container) return;
    let isDragging = false;
    let offsetX, offsetY;
    const header = container.querySelector('#mc-header');
    if (!header) return;

    header.addEventListener('mousedown', (e) => {
      isDragging = true;
      const rect = container.getBoundingClientRect();
      offsetX = e.clientX - rect.left;
      offsetY = e.clientY - rect.top;
      container.style.cursor = 'grabbing';
      e.preventDefault();
    });

    document.addEventListener('mousemove', (e) => {
      if (!isDragging) return;
      let x = e.clientX - offsetX;
      let y = e.clientY - offsetY;
      x = Math.max(0, Math.min(x, window.innerWidth - container.offsetWidth));
      y = Math.max(0, Math.min(y, window.innerHeight - container.offsetHeight));
      container.style.left = x + 'px';
      container.style.top = y + 'px';
      container.style.right = 'auto';
      chrome.storage.local.set({ clockPosition: { x, y } });
    });

    document.addEventListener('mouseup', () => {
      if (isDragging) {
        isDragging = false;
        container.style.cursor = 'default';
      }
    });
  }

  function loadPosition() {
    if (!container) return;
    chrome.storage.local.get('clockPosition', (result) => {
      if (result.clockPosition) {
        const { x, y } = result.clockPosition;
        container.style.left = x + 'px';
        container.style.top = y + 'px';
        container.style.right = 'auto';
      } else {
        container.style.right = '20px';
        container.style.top = '20px';
        container.style.left = 'auto';
      }
    });
  }

  function init() {
    if (document.getElementById('mc-container')) return;

    container = document.createElement('div');
    container.id = 'mc-container';
    container.innerHTML = `
      <div id="mc-header">Magister Clock</div>
      <svg id="mc-svg" width="120" height="120" viewBox="0 0 120 120">
        <circle id="mc-circle-bg" cx="60" cy="60" r="50" fill="none" stroke="#e0e0e0" stroke-width="8" />
        <circle id="mc-circle-progress" cx="60" cy="60" r="50" fill="none" stroke="#4CAF50" stroke-width="8"
                stroke-dasharray="314.159" stroke-dashoffset="0"
                transform="rotate(-90 60 60)" />
        <text id="mc-time-text" x="60" y="65" text-anchor="middle" font-size="22" font-weight="700" fill="#333">--:--</text>
      </svg>
      <div id="mc-label">Loading...</div>
    `;
    document.body.appendChild(container);

    loadSettings(() => {
      applySettings();
      loadPosition();
      makeDraggable();
      updateDisplay();
      if (updateInterval) clearInterval(updateInterval);
      updateInterval = setInterval(updateDisplay, 1000);
    });

    chrome.storage.onChanged.addListener((changes, namespace) => {
      if (namespace === 'local') {
        let needsUpdate = false;
        Object.keys(defaultSettings).forEach(key => {
          if (changes[key]) {
            currentSettings[key] = changes[key].newValue;
            needsUpdate = true;
          }
        });
        if (needsUpdate) {
          applySettings();
          updateDisplay();
        }
      }
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();