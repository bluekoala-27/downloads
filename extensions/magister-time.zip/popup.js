document.addEventListener('DOMContentLoaded', () => {
  const primaryColor = document.getElementById('primaryColor');
  const bgCircleColor = document.getElementById('bgCircleColor');
  const bgColor = document.getElementById('bgColor');
  const textColor = document.getElementById('textColor');
  const headerText = document.getElementById('headerText');
  const fontSize = document.getElementById('fontSize');
  const fontSizeValue = document.getElementById('fontSizeValue');
  const fontWeight = document.getElementById('fontWeight');
  const fontFamily = document.getElementById('fontFamily');
  const sizeScale = document.getElementById('sizeScale');
  const sizeValue = document.getElementById('sizeValue');
  const resetBtn = document.getElementById('resetPosition');
  const statusMsg = document.getElementById('statusMessage');

  // Load saved settings
  chrome.storage.local.get([
    'primaryColor', 'bgCircleColor', 'bgColor', 'textColor',
    'headerText', 'fontSize', 'fontWeight', 'fontFamily', 'sizeScale'
  ], (data) => {
    if (data.primaryColor) primaryColor.value = data.primaryColor;
    if (data.bgCircleColor) bgCircleColor.value = data.bgCircleColor;
    if (data.bgColor) bgColor.value = data.bgColor;
    if (data.textColor) textColor.value = data.textColor;
    if (data.headerText) headerText.value = data.headerText;
    if (data.fontSize) {
      fontSize.value = data.fontSize;
      fontSizeValue.textContent = data.fontSize + 'px';
    }
    if (data.fontWeight) fontWeight.value = data.fontWeight;
    if (data.fontFamily) fontFamily.value = data.fontFamily;
    if (data.sizeScale) {
      sizeScale.value = data.sizeScale;
      sizeValue.textContent = Math.round(data.sizeScale * 100) + '%';
    }
  });

  const saveSettings = () => {
    const settings = {
      primaryColor: primaryColor.value,
      bgCircleColor: bgCircleColor.value,
      bgColor: bgColor.value,
      textColor: textColor.value,
      headerText: headerText.value,
      fontSize: parseFloat(fontSize.value),
      fontWeight: fontWeight.value,
      fontFamily: fontFamily.value,
      sizeScale: parseFloat(sizeScale.value)
    };
    chrome.storage.local.set(settings, () => {
      statusMsg.textContent = 'Settings saved';
      setTimeout(() => statusMsg.textContent = '', 1500);
    });
  };

  // Save on change events (user finishes interaction)
  primaryColor.addEventListener('change', saveSettings);
  bgCircleColor.addEventListener('change', saveSettings);
  bgColor.addEventListener('change', saveSettings);
  textColor.addEventListener('change', saveSettings);
  headerText.addEventListener('change', saveSettings);
  fontSize.addEventListener('change', saveSettings);
  fontWeight.addEventListener('change', saveSettings);
  fontFamily.addEventListener('change', saveSettings);
  sizeScale.addEventListener('change', saveSettings);

  // Live preview for range sliders
  fontSize.addEventListener('input', () => {
    fontSizeValue.textContent = fontSize.value + 'px';
  });
  sizeScale.addEventListener('input', () => {
    sizeValue.textContent = Math.round(sizeScale.value * 100) + '%';
  });

  resetBtn.addEventListener('click', () => {
    chrome.storage.local.remove('clockPosition', () => {
      statusMsg.textContent = 'Position reset. Refresh the page.';
      setTimeout(() => statusMsg.textContent = '', 2000);
    });
  });
});