// background.js
chrome.action.onClicked.addListener((tab) => {
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    world: 'MAIN', // run in page context, so window.fake works
    func: () => {
      // ---------- YOUR SCRIPT STARTS HERE ----------
      (function () {
        if (window.fake) return;
        let e = !1,
          t = document.body.style.overflow,
          n = document.documentElement.style.overflow,
          o = document.body.style.userSelect,
          l = !1;

        function c() {
          l || (
            document.body.style.overflow = 'hidden',
            document.documentElement.style.overflow = 'hidden',
            document.body.style.userSelect = 'none',
            l = !0
          );
        }
        function u() {
          l && (
            document.body.style.overflow = t,
            document.documentElement.style.overflow = n,
            document.body.style.userSelect = o,
            l = !1
          );
        }
        function s(t) {
          if (!l) return;
          [
            'Tab', 'Enter', ' ', 'Space', 'ArrowUp', 'ArrowDown',
            'ArrowLeft', 'ArrowRight', 'Escape', 'PageUp', 'PageDown',
            'Home', 'End'
          ].includes(t.key) || t.key === ' ' || t.code === 'Space'
            ? (t.preventDefault(), t.stopPropagation(), t.stopImmediatePropagation())
            : void 0;
        }

        document.addEventListener('keydown', s, { capture: !0, passive: !1 });
        document.addEventListener('keyup', s, { capture: !0, passive: !1 });
        document.addEventListener('keypress', s, { capture: !0, passive: !1 });

        let i = document.createElement('style');
        i.textContent = '@keyframes fake-spin{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}';
        document.head.appendChild(i);

        let r = document.createElement('div');
        r.id = 'fake-mode-menu';
        r.style.cssText =
          'position:fixed;bottom:20px;right:20px;background:rgba(0,0,0,0.6);backdrop-filter:blur(4px);padding:8px;border-radius:8px;display:flex;gap:8px;z-index:2147483647;border:1px solid rgba(255,255,255,0.2);box-shadow:0 4px 12px rgba(0,0,0,0.3);';

        let d = (e, t) => {
          let n = document.createElement('button');
          n.textContent = e;
          n.style.cssText =
            'padding:6px 12px;border:none;border-radius:4px;font-size:13px;font-weight:bold;cursor:pointer;background:#fff;color:#333;transition:background 0.15s;border:1px solid rgba(255,255,255,0.3);';
          n.addEventListener('mouseenter', () => n.style.background = '#e0e0e0');
          n.addEventListener('mouseleave', () => n.style.background = '#fff');
          n.addEventListener('click', (e) => { e.stopPropagation(); a(t); });
          return n;
        };

        r.appendChild(d('Loading', 'loading'));
        r.appendChild(d('Error', 'error'));
        r.appendChild(d('Timeout 404', 'timeout'));
        document.body.appendChild(r);

        let v = document.createElement('div');
        v.id = 'fake-loading-overlay';
        v.style.cssText =
          'position:fixed;top:0;left:0;width:100vw;height:100vh;z-index:2147483646;display:none;flex-direction:column;align-items:center;justify-content:center;pointer-events:auto;backdrop-filter:blur(2px);';
        let m = document.createElement('div');
        m.style.cssText =
          'display:flex;justify-content:center;align-items:center;min-height:80px;margin-bottom:20px;';
        let g = document.createElement('div');
        g.style.cssText =
          'font-family:Arial,sans-serif;font-size:24px;font-weight:500;text-shadow:0 2px 8px rgba(0,0,0,0.3);text-align:center;padding:0 20px;';
        v.appendChild(m);
        v.appendChild(g);
        document.body.appendChild(v);

        let b = {
          loading: {
            overlayBg: 'rgba(128,128,128,0.6)',
            cursor: 'wait',
            icon: () => {
              let e = document.createElement('div');
              e.style.cssText =
                'width:50px;height:50px;border:5px solid rgba(255,255,255,0.3);border-top:5px solid #fff;border-radius:50%;animation:fake-spin 1s linear infinite;box-shadow:0 2px 8px rgba(0,0,0,0.2);';
              return e;
            },
            message: 'Loading...',
            messageStyle: { color: '#fff' }
          },
          error: {
            overlayBg: '#b91c1c',
            cursor: 'not-allowed',
            icon: () => {
              let e = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
              e.setAttribute('width', '60');
              e.setAttribute('height', '60');
              e.setAttribute('viewBox', '0 0 24 24');
              e.setAttribute('fill', 'none');
              e.setAttribute('stroke', '#fff');
              e.setAttribute('stroke-width', '2');
              e.setAttribute('stroke-linecap', 'round');
              e.setAttribute('stroke-linejoin', 'round');
              let t = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
              t.setAttribute('cx', '12');
              t.setAttribute('cy', '12');
              t.setAttribute('r', '10');
              let n = document.createElementNS('http://www.w3.org/2000/svg', 'line');
              n.setAttribute('x1', '12');
              n.setAttribute('y1', '8');
              n.setAttribute('x2', '12');
              n.setAttribute('y2', '12');
              let o = document.createElementNS('http://www.w3.org/2000/svg', 'line');
              o.setAttribute('x1', '12');
              o.setAttribute('y1', '16');
              o.setAttribute('x2', '12.01');
              o.setAttribute('y2', '16');
              e.appendChild(t);
              e.appendChild(n);
              e.appendChild(o);
              return e;
            },
            message: 'An unexpected error occurred',
            messageStyle: { color: '#fff', fontSize: '24px' }
          },
          timeout: {
            overlayBg: '#b45309',
            cursor: 'not-allowed',
            icon: () => {
              let e = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
              e.setAttribute('width', '60');
              e.setAttribute('height', '60');
              e.setAttribute('viewBox', '0 0 24 24');
              e.setAttribute('fill', 'none');
              e.setAttribute('stroke', '#fff');
              e.setAttribute('stroke-width', '2');
              e.setAttribute('stroke-linecap', 'round');
              e.setAttribute('stroke-linejoin', 'round');
              let t = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
              t.setAttribute('cx', '12');
              t.setAttribute('cy', '12');
              t.setAttribute('r', '10');
              let n = document.createElementNS('http://www.w3.org/2000/svg', 'polyline');
              n.setAttribute('points', '12 6 12 12 16 14');
              e.appendChild(t);
              e.appendChild(n);
              return e;
            },
            message: 'Request Timeout (404)',
            messageStyle: { color: '#fff', fontSize: '24px' }
          }
        };

        function a(e) {
          let t = b[e];
          if (!t) return;
          c();
          v.style.backgroundColor = t.overlayBg;
          v.style.cursor = t.cursor;
          v.style.display = 'flex';
          m.innerHTML = '';
          m.appendChild(t.icon());
          g.textContent = t.message;
          Object.assign(g.style, t.messageStyle);
          r.style.display = 'none';
        }

        function p() {
          v && v.remove();
          r && r.remove();
          i.remove();
          u();
          document.removeEventListener('keydown', s, { capture: !0 });
          document.removeEventListener('keyup', s, { capture: !0 });
          document.removeEventListener('keypress', s, { capture: !0 });
          document.removeEventListener('keydown', f);
          delete window.fake;
        }

        function f(e) {
          e.key === 'Escape' && (e.preventDefault(), e.stopPropagation(), p());
        }

        document.addEventListener('keydown', f, { capture: !0 });

        window.fake = function (e) {
          if (e === 'menu') {
            if (!document.getElementById('fake-mode-menu')) {
              document.body.appendChild(r);
              return;
            }
            r.style.display = 'flex';
            v.style.display = 'none';
            u();
          } else if (e === 'off') {
            p();
          } else {
            a(e);
          }
        };
      })();
      // ---------- YOUR SCRIPT ENDS ----------
    }
  });
});