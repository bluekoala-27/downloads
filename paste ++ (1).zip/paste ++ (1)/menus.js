// menus.js – central list of all context menu items
export const MENUS = [
  { id: "exploit",        title: "Fake Exploit Code",       type: "prank" },
  { id: "unicode",        title: "Weird Unicode",           type: "prank" },
  { id: "timestamp",      title: "Fake Audio Timestamp",    type: "prank" },
  { id: "rickroll",       title: "Rickroll Link",           type: "prank" },
  { id: "fakeError",      title: "Fake System Error",       type: "prank" },
  { id: "fakeVirus",      title: "Fake Virus Alert",        type: "prank" },
  { id: "glitchText",     title: "Alien Text",              type: "prank" },
  { id: "glitchKeyboard", title: "⌨️ Glitch Keyboard",       type: "prank" },
  { id: "megaUnicode",    title: "🚀 Mega Unicode Stack",   type: "prank" },

  { id: "pythonCode",     title: "Python Snippet",          type: "handy" },
  { id: "loremIpsum",     title: "Lorem Ipsum",             type: "handy" },
  { id: "jsonPlaceholder",title: "JSON Placeholder",        type: "handy" },
  { id: "metaTags",       title: "Meta Tags Template",      type: "handy" },
  { id: "dateTime",       title: "Current Date/Time",       type: "handy" },
  { id: "currentUrl",     title: "Current Page URL",        type: "handy" },
  { id: "isoTimestamp",   title: "ISO Timestamp",           type: "handy" },
  { id: "randomSentence", title: "Random Sentence",         type: "handy" },
  { id: "leetSpeak",      title: "Leetspeak Phrase",        type: "handy" },

  { id: "customText",     title: "Custom Text…",            type: "action" },
  { id: "clearField",     title: "Clear Field",             type: "action" },
  { id: "toUpperCase",    title: "UPPERCASE Selection",     type: "action" },
  { id: "toLowerCase",    title: "lowercase Selection",     type: "action" },
  { id: "reverseText",    title: "Reverse Selection",       type: "action" },
];