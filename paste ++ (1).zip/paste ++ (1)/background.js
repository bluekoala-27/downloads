// background.js – creates context menus and notifies content script with robust fallback

const MENUS = [
  { id: "exploit",        title: "Fake Exploit Code",       type: "prank" },
  { id: "unicode",        title: "Weird Unicode",           type: "prank" },
  { id: "timestamp",      title: "Fake Audio Timestamp",    type: "prank" },
  { id: "rickroll",       title: "Rickroll Link",           type: "prank" },
  { id: "fakeError",      title: "Fake System Error",       type: "prank" },
  { id: "fakeVirus",      title: "Fake Virus Alert",        type: "prank" },
  { id: "glitchText",     title: "Alien Text",              type: "prank" },
  { id: "glitchKeyboard", title: "⌨️ Glitch Keyboard",       type: "prank" },
  { id: "megaUnicode",    title: "🚀 Mega Unicode Stack",   type: "prank" },
  { id: "pythonCode",     title: "Python Snippet",          type: "handy" },
  { id: "loremIpsum",     title: "Lorem Ipsum",             type: "handy" },
  { id: "jsonPlaceholder",title: "JSON Placeholder",        type: "handy" },
  { id: "metaTags",       title: "Meta Tags Template",      type: "handy" },
  { id: "dateTime",       title: "Current Date/Time",       type: "handy" },
  { id: "currentUrl",     title: "Current Page URL",        type: "handy" },
  { id: "isoTimestamp",   title: "ISO Timestamp",           type: "handy" },
  { id: "randomSentence", title: "Random Sentence",         type: "handy" },
  { id: "leetSpeak",      title: "Leetspeak Phrase",        type: "handy" },
  { id: "customText",     title: "Custom Text…",            type: "action" },
  { id: "clearField",     title: "Clear Field",             type: "action" },
  { id: "toUpperCase",    title: "UPPERCASE Selection",     type: "action" },
  { id: "toLowerCase",    title: "lowercase Selection",     type: "action" },
  { id: "reverseText",    title: "Reverse Selection",       type: "action" },
  { id: "calculator",         title: "🧮 Calculator",           type: "handy" },
  { id: "advancedCalculator", title: "📐 Advanced Calculator",  type: "handy" },
  { id: "unicodeKeyboard",    title: "🔤 Unicode Look-alike Keyboard", type: "prank" },
];

const CONTENT_SCRIPTS = [
  "helpers.js",
  "features/exploit.js",
  "features/unicode.js",
  "features/timestamp.js",
  "features/rickroll.js",
  "features/fakeError.js",
  "features/fakeVirus.js",
  "features/glitchText.js",
  "features/glitchKeyboard.js",
  "features/megaUnicode.js",
  "features/pythonCode.js",
  "features/loremIpsum.js",
  "features/jsonPlaceholder.js",
  "features/metaTags.js",
  "features/dateTime.js",
  "features/currentUrl.js",
  "features/isoTimestamp.js",
  "features/randomSentence.js",
  "features/leetSpeak.js",
  "features/customText.js",
  "features/clearField.js",
  "features/toUpperCase.js",
  "features/toLowerCase.js",
  "features/reverseText.js",
  "features/calculator.js",
  "features/advancedCalculator.js",
  "features/unicodeKeyboard.js",
  "content.js"
];

function createMenus() {
  chrome.contextMenus.removeAll(() => {
    for (const item of MENUS) {
      chrome.contextMenus.create({
        id: item.id,
        title: item.title,
        contexts: ["editable"]
      });
    }
    console.log(`Created ${MENUS.length} context menus`);
  });
}

chrome.runtime.onInstalled.addListener(createMenus);
createMenus();

chrome.contextMenus.onClicked.addListener((info, tab) => {
  const sendMessage = () => chrome.tabs.sendMessage(
    tab.id,
    { type: 'CONTEXT_MENU_CLICKED', menuId: info.menuItemId }
  );

  sendMessage().catch(() => {
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: CONTENT_SCRIPTS
    }).then(() => {
      return sendMessage();
    }).catch(err => console.error("Failed to inject content scripts:", err));
  });
});