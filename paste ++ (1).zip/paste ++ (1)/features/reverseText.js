(function() {
  const H = window.PastePlusPlusHelpers;
  window.PastePlusPlus = window.PastePlusPlus || {};
  window.PastePlusPlus.reverseText = function(field) {
    H.transformSelection(field, s => s.split('').reverse().join(''));
  };
})();