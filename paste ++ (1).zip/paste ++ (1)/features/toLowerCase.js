(function() {
  const H = window.PastePlusPlusHelpers;
  window.PastePlusPlus = window.PastePlusPlus || {};
  window.PastePlusPlus.toLowerCase = function(field) {
    H.transformSelection(field, s => s.toLowerCase());
  };
})();