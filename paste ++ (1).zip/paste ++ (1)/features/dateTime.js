(function() {
  const H = window.PastePlusPlusHelpers;
  window.PastePlusPlus = window.PastePlusPlus || {};
  window.PastePlusPlus.dateTime = function(field) {
    H.injectIntoField(field, new Date().toLocaleString());
  };
})();