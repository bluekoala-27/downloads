(function() {
  const H = window.PastePlusPlusHelpers;
  window.PastePlusPlus = window.PastePlusPlus || {};
  window.PastePlusPlus.unicode = function(field) {
    let chaos = "";
    const inv = ["\u200B","\u200C","\u200D","\u200E","\u200F","\u2060","\uFEFF"];
    for (let i = 0; i < 20; i++) chaos += inv[Math.floor(Math.random() * inv.length)];
    chaos += "H̸̓͠e̸̔̓l̵̽̆p̸̑͐ ";
    let lag = "A";
    for (let i = 0; i < 60; i++) lag += String.fromCharCode(0x0300 + Math.floor(Math.random()*80));
    chaos += lag + "";
    chaos += "\u202E}dlrow olleH\u202C ";
    chaos += "��";
    for (let i = 0; i < 10; i++) chaos += inv[Math.floor(Math.random() * inv.length)];
    H.injectIntoField(field, chaos);
  };
})();