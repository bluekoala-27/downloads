(function() {
  const H = window.PastePlusPlusHelpers;
  window.PastePlusPlus = window.PastePlusPlus || {};
  window.PastePlusPlus.rickroll = function(field) {
    H.injectIntoField(field, "https://www.youtube.com/watch?v=dQw4w9WgXcQ");
  };
})();