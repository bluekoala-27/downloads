(function() {
  const H = window.PastePlusPlusHelpers;
  window.PastePlusPlus = window.PastePlusPlus || {};

  window.PastePlusPlus.glitchKeyboard = function() {
    if (document.getElementById('glitch-keyboard')) return;
    const targetField = H.findTarget();
    if (!targetField) {
      H.showToast("❌ Focus a text field before opening the keyboard!");
      return;
    }

    const keyboardDiv = document.createElement('div');
    keyboardDiv.id = 'glitch-keyboard';
    keyboardDiv.style.cssText = `
      position: fixed; top: 100px; left: 100px; width: 480px;
      background: #0a0a0a; border: 2px solid #ff00cc; border-radius: 12px;
      box-shadow: 0 0 20px rgba(255,0,204,0.5); font-family: monospace;
      z-index: 1000000; user-select: none; backdrop-filter: blur(8px);
    `;

    const titleBar = document.createElement('div');
    titleBar.style.cssText = `
      background: #1a1a2e; padding: 8px 12px; border-radius: 10px 10px 0 0;
      cursor: move; color: #ff00cc; font-weight: bold; display: flex;
      justify-content: space-between; border-bottom: 1px solid #ff00cc;
    `;
    titleBar.innerHTML = `<span>⌨️ GLITCH KEYBOARD (type → glitch text)</span><span id="close-keyboard" style="cursor:pointer; background:#ff00cc; color:#000; padding:0 6px; border-radius:4px;">✖</span>`;
    keyboardDiv.appendChild(titleBar);

    const buttonsContainer = document.createElement('div');
    buttonsContainer.style.cssText = `
      padding: 12px; display: grid; grid-template-columns: repeat(10, 1fr);
      gap: 6px; background: #111; border-radius: 0 0 10px 10px;
    `;

    const keys = ['1','2','3','4','5','6','7','8','9','0','q','w','e','r','t','y','u','i','o','p','a','s','d','f','g','h','j','k','l',';','z','x','c','v','b','n','m',',','.','/','⌫','Space','Enter'];
    const combiningChars = Array.from({ length: 80 }, (_, i) => String.fromCharCode(0x0300 + i));

    function glitchChar(ch) {
      if (ch === ' ') return ' ';
      let glitched = ch;
      for (let i = 0; i < Math.floor(Math.random() * 4) + 1; i++) {
        glitched += combiningChars[Math.floor(Math.random() * combiningChars.length)];
      }
      return glitched;
    }

    function injectIntoCapturedField(text) {
      if (!targetField || !document.body.contains(targetField)) {
        H.showToast("❌ Target field lost. Close and reopen keyboard.");
        keyboardDiv.remove();
        return false;
      }
      return H.injectIntoField(targetField, text);
    }

    keys.forEach(key => {
      const btn = document.createElement('button');
      btn.textContent = key;
      btn.style.cssText = `background:#222; color:#0f0; border:1px solid #ff00cc; border-radius:6px; padding:8px 0; font-size:14px; cursor:pointer; font-family:monospace; transition:0.1s;`;
      btn.onmouseover = () => btn.style.background = '#ff00cc33';
      btn.onmouseout = () => btn.style.background = '#222';
      btn.onclick = () => {
        if (key === '⌫') {
          if (targetField.tagName === 'INPUT' || targetField.tagName === 'TEXTAREA') {
            targetField.value = targetField.value.slice(0, -1);
            targetField.dispatchEvent(new Event('input', { bubbles: true }));
          } else if (targetField.isContentEditable) {
            const sel = window.getSelection();
            if (sel.rangeCount) {
              const range = sel.getRangeAt(0);
              if (range.collapsed && range.startOffset > 0) {
                range.setStart(range.startContainer, range.startOffset - 1);
                range.deleteContents();
              } else range.deleteContents();
            }
          }
          targetField.focus();
        } else if (key === 'Space') injectIntoCapturedField(' ');
        else if (key === 'Enter') injectIntoCapturedField('\n');
        else injectIntoCapturedField(glitchChar(key));
      };
      buttonsContainer.appendChild(btn);
    });

    keyboardDiv.appendChild(buttonsContainer);
    document.body.appendChild(keyboardDiv);

    let isDragging = false, offsetX, offsetY;
    const onMouseMove = (e) => {
      if (!isDragging) return;
      keyboardDiv.style.left = (e.clientX - offsetX) + 'px';
      keyboardDiv.style.top = (e.clientY - offsetY) + 'px';
    };
    const onMouseUp = () => { isDragging = false; keyboardDiv.style.cursor = 'default'; };

    titleBar.addEventListener('mousedown', (e) => {
      if (e.target.id === 'close-keyboard') return;
      isDragging = true;
      offsetX = e.clientX - keyboardDiv.offsetLeft;
      offsetY = e.clientY - keyboardDiv.offsetTop;
      keyboardDiv.style.cursor = 'grabbing';
      e.preventDefault();
      window.addEventListener('mousemove', onMouseMove);
      window.addEventListener('mouseup', onMouseUp);
    });

    document.getElementById('close-keyboard').onclick = () => {
      keyboardDiv.remove();
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
    };
  };
})();