(function() {
  const H = window.PastePlusPlusHelpers;
  window.PastePlusPlus = window.PastePlusPlus || {};

  window.PastePlusPlus.advancedCalculator = function(field) {
    if (document.getElementById('advanced-calculator')) return;
    const targetField = field || H.findTarget();
    if (!targetField) {
      H.showToast("❌ Focus a text field first.");
      return;
    }

    const win = document.createElement('div');
    win.id = 'advanced-calculator';
    win.style.cssText = `
      position: fixed; top: 100px; left: 100px; width: 340px;
      background: #1a1a2e; border: 2px solid #7e57c2; border-radius: 12px;
      box-shadow: 0 0 20px rgba(126,87,194,0.7); font-family: 'Segoe UI', monospace;
      z-index: 1000000; user-select: none; backdrop-filter: blur(8px);
      color: #eee;
    `;

    const titleBar = document.createElement('div');
    titleBar.style.cssText = `
      background: #2a2a40; padding: 8px 12px; border-radius: 10px 10px 0 0;
      cursor: move; display: flex; justify-content: space-between;
      border-bottom: 1px solid #7e57c2; font-weight: bold;
    `;
    titleBar.innerHTML = `<span>📐 Advanced Calculator</span><span id="adv-close" style="cursor:pointer; background:#ff5555; color:#000; padding:0 6px; border-radius:4px;">✖</span>`;
    win.appendChild(titleBar);

    const display = document.createElement('div');
    display.style.cssText = `
      background: #111; margin: 10px; padding: 10px; border-radius: 6px;
      font-size: 18px; text-align: right; overflow: hidden;
      border: 1px solid #7e57c2; min-height: 28px;
    `;
    display.textContent = '0';
    win.appendChild(display);

    const buttonsDiv = document.createElement('div');
    buttonsDiv.style.cssText = `
      display: grid; grid-template-columns: repeat(6, 1fr);
      gap: 4px; padding: 10px;
    `;
    win.appendChild(buttonsDiv);

    const btnDefs = [
      'sin', 'cos', 'tan', '(', ')', '⌫',
      'asin','acos','atan','^', '√', 'C',
      'log', 'ln', 'exp', '7', '8', '9',
      'abs', 'floor','ceil', '4', '5', '6',
      'pi', 'e', 'round', '1', '2', '3',
      'pow', '%', '=', '0', '.', '/',
      '*', '-', '+'
    ];

    btnDefs.forEach(label => {
      const btn = document.createElement('button');
      btn.textContent = label;
      btn.style.cssText = `
        background: #3a3a4a; color: #fff; border: 1px solid #555;
        border-radius: 6px; padding: 8px 0; font-size: 13px;
        cursor: pointer; transition: 0.1s;
      `;
      if (label === '=') btn.style.background = '#2e7d32';
      if (label === 'C') btn.style.background = '#c62828';
      if (label === '⌫') btn.style.background = '#b26a00';
      btn.onmouseover = () => btn.style.filter = 'brightness(1.3)';
      btn.onmouseout = () => btn.style.filter = 'none';
      btn.onclick = () => handleButton(label);
      buttonsDiv.appendChild(btn);
    });

    let currentInput = '';

    function handleButton(label) {
      if (label === 'C') {
        currentInput = '';
        display.textContent = '0';
      } else if (label === '⌫') {
        currentInput = currentInput.slice(0, -1);
        display.textContent = currentInput || '0';
      } else if (label === '=') {
        try {
          // Note: √ and ^ are already understood by the parser, so no need to convert
          const result = H.evaluateMathExpression(currentInput);
          H.injectIntoField(targetField, String(result));
          currentInput = '';
          display.textContent = String(result); // Keep result visible, window stays open
        } catch (e) {
          H.showToast("❌ Invalid expression");
          display.textContent = 'Error';
          currentInput = '';
        }
      } else if (['sin','cos','tan','asin','acos','atan','log','ln','abs','floor','ceil','round','pow','exp'].includes(label)) {
        currentInput += label + '(';
        display.textContent = currentInput;
      } else if (label === '√') {
        currentInput += 'sqrt(';
        display.textContent = currentInput;
      } else if (label === 'pi' || label === 'e') {
        currentInput += label;
        display.textContent = currentInput;
      } else {
        currentInput += label;
        display.textContent = currentInput;
      }
    }

    document.body.appendChild(win);

    let isDragging = false, offsetX, offsetY;
    const onMouseMove = (e) => {
      if (!isDragging) return;
      win.style.left = (e.clientX - offsetX) + 'px';
      win.style.top = (e.clientY - offsetY) + 'px';
    };
    const onMouseUp = () => { isDragging = false; win.style.cursor = 'default'; };
    titleBar.addEventListener('mousedown', (e) => {
      if (e.target.id === 'adv-close') return;
      isDragging = true;
      offsetX = e.clientX - win.offsetLeft;
      offsetY = e.clientY - win.offsetTop;
      win.style.cursor = 'grabbing';
      e.preventDefault();
      window.addEventListener('mousemove', onMouseMove);
      window.addEventListener('mouseup', onMouseUp);
    });
    document.getElementById('adv-close').onclick = () => {
      win.remove();
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
    };
  };
})();