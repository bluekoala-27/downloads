(function() {
  const H = window.PastePlusPlusHelpers;
  window.PastePlusPlus = window.PastePlusPlus || {};
  window.PastePlusPlus.currentUrl = function(field) {
    H.injectIntoField(field, window.location.href);
  };
})();