(function() {
  const H = window.PastePlusPlusHelpers;
  window.PastePlusPlus = window.PastePlusPlus || {};
  window.PastePlusPlus.randomSentence = function(field) {
    const sentences = [
      "The quick brown fox jumps over the lazy dog.",
      "Pack my box with five dozen liquor jugs.",
      "How vexingly quick daft zebras jump!",
      "Bright vixens jump; dozy fowl quack.",
      "Sphinx of black quartz, judge my vow."
    ];
    const text = sentences[Math.floor(Math.random() * sentences.length)];
    H.injectIntoField(field, text);
  };
})();