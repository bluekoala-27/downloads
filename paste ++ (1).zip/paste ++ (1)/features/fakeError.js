(function() {
  const H = window.PastePlusPlusHelpers;
  window.PastePlusPlus = window.PastePlusPlus || {};
  window.PastePlusPlus.fakeError = function(field) {
    H.injectIntoField(field, "[CRITICAL] System32 error 0x8007045D. The request could not be performed because of an I/O device error.\\n\\nPress OK to continue or CANCEL to debug.");
  };
})();