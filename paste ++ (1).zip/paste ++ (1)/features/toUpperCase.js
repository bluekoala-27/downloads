(function() {
  const H = window.PastePlusPlusHelpers;
  window.PastePlusPlus = window.PastePlusPlus || {};
  window.PastePlusPlus.toUpperCase = function(field) {
    H.transformSelection(field, s => s.toUpperCase());
  };
})();