(function() {
  const H = window.PastePlusPlusHelpers;
  window.PastePlusPlus = window.PastePlusPlus || {};
  window.PastePlusPlus.loremIpsum = function(field) {
    H.injectIntoField(field, "Lorem ipsum dolor sit amet");
  };
})();