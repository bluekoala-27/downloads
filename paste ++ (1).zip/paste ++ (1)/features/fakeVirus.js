(function() {
  const H = window.PastePlusPlusHelpers;
  window.PastePlusPlus = window.PastePlusPlus || {};
  window.PastePlusPlus.fakeVirus = function(field) {
    H.injectIntoField(field, "⚠️ VIRUS DETECTED! Your files are being encrypted.\\n\\nCall 1-888-555-0192 to unlock your PC.\\n\\n[THIS IS A PRANK - NO ACTION TAKEN]");
  };
})();