(function() {
  const H = window.PastePlusPlusHelpers;
  window.PastePlusPlus = window.PastePlusPlus || {};
  window.PastePlusPlus.isoTimestamp = function(field) {
    H.injectIntoField(field, new Date().toISOString());
  };
})();