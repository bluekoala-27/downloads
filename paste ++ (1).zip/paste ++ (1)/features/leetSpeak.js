(function() {
  const H = window.PastePlusPlusHelpers;
  window.PastePlusPlus = window.PastePlusPlus || {};
  window.PastePlusPlus.leetSpeak = function(field) {
    H.injectIntoField(field, "7h15 15 4 l3375p34k phr4s3!");
  };
})();