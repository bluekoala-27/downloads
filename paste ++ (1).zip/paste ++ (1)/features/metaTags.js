(function() {
  const H = window.PastePlusPlusHelpers;
  window.PastePlusPlus = window.PastePlusPlus || {};
  window.PastePlusPlus.metaTags = function(field) {
    H.injectIntoField(field, '<meta charset="UTF-8">\n<meta name="viewport" content="width=device-width, initial-scale=1.0">\n<meta name="description" content="Your description here">');
  };
})();