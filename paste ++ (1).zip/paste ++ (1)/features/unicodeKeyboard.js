(function() {
  const H = window.PastePlusPlusHelpers;
  window.PastePlusPlus = window.PastePlusPlus || {};

  // Mapping of normal characters to fullwidth look-alikes
  const LOOKALIKE_MAP = {
    '1':'１','2':'２','3':'３','4':'４','5':'５',
    '6':'６','7':'７','8':'８','9':'９','0':'０',
    'q':'ｑ','w':'ｗ','e':'ｅ','r':'ｒ','t':'ｔ','y':'ｙ','u':'ｕ','i':'ｉ','o':'ｏ','p':'ｐ',
    'a':'ａ','s':'ｓ','d':'ｄ','f':'ｆ','g':'ｇ','h':'ｈ','j':'ｊ','k':'ｋ','l':'ｌ',
    'z':'ｚ','x':'ｘ','c':'ｃ','v':'ｖ','b':'ｂ','n':'ｎ','m':'ｍ',
    ',':'，','.':'．','/':'／',';':'；',' ':' ', // space stays
    '⌫':'⌫','Space':' ','Enter':'\n'
  };

  window.PastePlusPlus.unicodeKeyboard = function(field) {
    if (document.getElementById('unicode-keyboard')) return;
    const targetField = field || H.findTarget();
    if (!targetField) {
      H.showToast("❌ Focus a text field first.");
      return;
    }

    const win = document.createElement('div');
    win.id = 'unicode-keyboard';
    win.style.cssText = `
      position: fixed; top: 100px; left: 100px; width: 480px;
      background: #0a0a0a; border: 2px solid #00ccff; border-radius: 12px;
      box-shadow: 0 0 20px rgba(0,204,255,0.5); font-family: monospace;
      z-index: 1000000; user-select: none; backdrop-filter: blur(8px);
    `;

    const titleBar = document.createElement('div');
    titleBar.style.cssText = `
      background: #1a1a2e; padding: 8px 12px; border-radius: 10px 10px 0 0;
      cursor: move; color: #00ccff; font-weight: bold; display: flex;
      justify-content: space-between; border-bottom: 1px solid #00ccff;
    `;
    titleBar.innerHTML = `<span>🔤 Unicode Look-alike Keyboard</span><span id="unicode-keyboard-close" style="cursor:pointer; background:#00ccff; color:#000; padding:0 6px; border-radius:4px;">✖</span>`;
    win.appendChild(titleBar);

    const keysContainer = document.createElement('div');
    keysContainer.style.cssText = `
      padding: 12px; display: grid; grid-template-columns: repeat(10, 1fr);
      gap: 6px; background: #111; border-radius: 0 0 10px 10px;
    `;
    win.appendChild(keysContainer);

    const keys = ['1','2','3','4','5','6','7','8','9','0','q','w','e','r','t','y','u','i','o','p','a','s','d','f','g','h','j','k','l',';','z','x','c','v','b','n','m',',','.','/','⌫','Space','Enter'];

    keys.forEach(key => {
      const btn = document.createElement('button');
      btn.textContent = LOOKALIKE_MAP[key] || key;
      btn.style.cssText = `
        background:#222; color:#00ccff; border:1px solid #00ccff; border-radius:6px;
        padding:8px 0; font-size:14px; cursor:pointer; font-family:monospace; transition:0.1s;
      `;
      btn.onmouseover = () => btn.style.background = '#00ccff33';
      btn.onmouseout = () => btn.style.background = '#222';
      btn.onclick = () => {
        const output = LOOKALIKE_MAP[key] || key;
        if (output === '⌫') {
          if (targetField.tagName === 'INPUT' || targetField.tagName === 'TEXTAREA') {
            targetField.value = targetField.value.slice(0, -1);
            targetField.dispatchEvent(new Event('input', { bubbles: true }));
          } else if (targetField.isContentEditable) {
            const sel = window.getSelection();
            if (sel.rangeCount) {
              const range = sel.getRangeAt(0);
              if (range.collapsed && range.startOffset > 0) {
                range.setStart(range.startContainer, range.startOffset - 1);
                range.deleteContents();
              } else range.deleteContents();
            }
          }
          targetField.focus();
        } else if (output === '\n') {
          H.injectIntoField(targetField, '\n');
        } else {
          H.injectIntoField(targetField, output);
        }
      };
      keysContainer.appendChild(btn);
    });

    document.body.appendChild(win);

    let isDragging = false, offsetX, offsetY;
    const onMouseMove = (e) => {
      if (!isDragging) return;
      win.style.left = (e.clientX - offsetX) + 'px';
      win.style.top = (e.clientY - offsetY) + 'px';
    };
    const onMouseUp = () => { isDragging = false; win.style.cursor = 'default'; };
    titleBar.addEventListener('mousedown', (e) => {
      if (e.target.id === 'unicode-keyboard-close') return;
      isDragging = true;
      offsetX = e.clientX - win.offsetLeft;
      offsetY = e.clientY - win.offsetTop;
      win.style.cursor = 'grabbing';
      e.preventDefault();
      window.addEventListener('mousemove', onMouseMove);
      window.addEventListener('mouseup', onMouseUp);
    });
    document.getElementById('unicode-keyboard-close').onclick = () => {
      win.remove();
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
    };
  };
})();