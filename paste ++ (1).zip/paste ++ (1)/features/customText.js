(function() {
  const H = window.PastePlusPlusHelpers;
  window.PastePlusPlus = window.PastePlusPlus || {};
  window.PastePlusPlus.customText = function(field) {
    const userText = prompt("Enter text to paste:");
    if (userText !== null) {
      H.injectIntoField(field, userText);
    } else {
      H.showToast("ℹ️ Custom text cancelled.");
    }
  };
})();