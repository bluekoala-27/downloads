(function() {
  const H = window.PastePlusPlusHelpers;
  window.PastePlusPlus = window.PastePlusPlus || {};
  window.PastePlusPlus.glitchText = function(field) {
    H.injectIntoField(field, "G̷l̵i̷t̶c̸h̷y̴ ̷T̸e̵x̴t̸ ̸i̵s̶ ̵f̵u̷n̵!̷ 👾");
  };
})();