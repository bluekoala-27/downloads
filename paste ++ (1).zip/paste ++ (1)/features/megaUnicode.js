(function() {
  const H = window.PastePlusPlusHelpers;
  window.PastePlusPlus = window.PastePlusPlus || {};

  function buildMegaStack() {
    const base = 't';
    // Full Combining Diacritical Marks range (0300–036F)
    let stack = base;
    for (let cp = 0x0300; cp <= 0x036F; cp++) {
      stack += String.fromCodePoint(cp);
    }
    return stack;
  }

  window.PastePlusPlus.megaUnicode = function(field) {
    const text = buildMegaStack();
    H.injectIntoField(field, text);
  };
})();