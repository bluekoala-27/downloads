(function() {
  const H = window.PastePlusPlusHelpers;
  window.PastePlusPlus = window.PastePlusPlus || {};
  window.PastePlusPlus.clearField = function(field) {
    if (field.tagName === 'INPUT' || field.tagName === 'TEXTAREA') {
      field.value = "";
      field.dispatchEvent(new Event('input', { bubbles: true }));
    } else if (field.isContentEditable) {
      field.innerHTML = "";
      field.dispatchEvent(new Event('input', { bubbles: true }));
    }
    field.focus();
    H.showToast("🧹 Field cleared.");
  };
})();