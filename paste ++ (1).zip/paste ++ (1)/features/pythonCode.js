(function() {
  const H = window.PastePlusPlusHelpers;
  window.PastePlusPlus = window.PastePlusPlus || {};
  window.PastePlusPlus.pythonCode = function(field) {
    H.injectIntoField(field, "print('Hello, world!') # Python one-liner\nfor i in range(10): print(i)");
  };
})();