(function() {
  const H = window.PastePlusPlusHelpers;
  window.PastePlusPlus = window.PastePlusPlus || {};
  window.PastePlusPlus.jsonPlaceholder = function(field) {
    H.injectIntoField(field, '{\n  "name": "John Doe",\n  "email": "john@example.com",\n  "age": 30\n}');
  };
})();