// helpers.js – shared DOM utilities and math expression evaluator
window.PastePlusPlusHelpers = {
  findTarget() {
    const el = document.activeElement;
    if (el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.isContentEditable)) {
      return el;
    }
    return document.querySelector('input, textarea, [contenteditable="true"]');
  },

  injectIntoField(field, text) {
    if (!field) return false;
    if (field.tagName === 'INPUT' || field.tagName === 'TEXTAREA') {
      const start = field.selectionStart || 0;
      const end = field.selectionEnd || 0;
      field.value = field.value.slice(0, start) + text + field.value.slice(end);
      field.selectionStart = field.selectionEnd = start + text.length;
      field.dispatchEvent(new Event('input', { bubbles: true }));
      field.dispatchEvent(new Event('change', { bubbles: true }));
    } else if (field.isContentEditable) {
      const sel = window.getSelection();
      if (sel.rangeCount) {
        const range = sel.getRangeAt(0);
        range.deleteContents();
        range.insertNode(document.createTextNode(text));
        range.collapse(false);
      } else {
        field.appendChild(document.createTextNode(text));
      }
      field.dispatchEvent(new Event('input', { bubbles: true }));
    }
    field.focus();
    return true;
  },

  showToast(msg) {
    const toast = document.createElement('div');
    toast.textContent = msg;
    toast.style.cssText = `
      position: fixed; bottom: 12px; left: 12px; background: #1a1a2e;
      color: #0f0; font-family: monospace; padding: 6px 12px;
      border-radius: 8px; z-index: 999999; font-size: 13px;
      border-left: 3px solid #0f0; box-shadow: 0 2px 8px black;
      pointer-events: none; transition: opacity 0.2s;
    `;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 2000);
  },

  transformSelection(field, transformFn) {
    if (!field) return;
    if (field.tagName === 'INPUT' || field.tagName === 'TEXTAREA') {
      const start = field.selectionStart;
      const end = field.selectionEnd;
      if (start === null || end === null || start === end) {
        this.showToast("ℹ️ No text selected.");
        return;
      }
      const selected = field.value.substring(start, end);
      const transformed = transformFn(selected);
      field.value = field.value.substring(0, start) + transformed + field.value.substring(end);
      field.selectionStart = start;
      field.selectionEnd = start + transformed.length;
      field.dispatchEvent(new Event('input', { bubbles: true }));
    } else if (field.isContentEditable) {
      const sel = window.getSelection();
      if (!sel.rangeCount || sel.isCollapsed) {
        this.showToast("ℹ️ No text selected.");
        return;
      }
      const range = sel.getRangeAt(0);
      const selectedText = range.toString();
      const transformed = transformFn(selectedText);
      range.deleteContents();
      range.insertNode(document.createTextNode(transformed));
      range.collapse(false);
      field.dispatchEvent(new Event('input', { bubbles: true }));
    }
    field.focus();
  },

  // Safe math expression evaluator (no eval/Function)
  evaluateMathExpression(expr) {
    // Tokenizer
    const tokens = [];
    let i = 0;
    while (i < expr.length) {
      const ch = expr[i];
      if (ch === ' ') { i++; continue; }
      if (/\d|\./.test(ch)) {
        let num = '';
        while (i < expr.length && /\d|\./.test(expr[i])) {
          num += expr[i++];
        }
        tokens.push({ type: 'number', value: parseFloat(num) });
      } else if (/[a-zA-Z]/.test(ch)) {
        let word = '';
        while (i < expr.length && /[a-zA-Z]/.test(expr[i])) {
          word += expr[i++];
        }
        if (['pi', 'e'].includes(word)) {
          tokens.push({ type: 'constant', value: word });
        } else if (['sin','cos','tan','asin','acos','atan','sqrt','log','ln','abs','floor','ceil','round','exp','pow'].includes(word)) {
          tokens.push({ type: 'function', value: word });
        } else {
          throw new Error('Unknown identifier: ' + word);
        }
      } else if ('+-*/^()%,'.includes(ch)) {
        tokens.push({ type: 'operator', value: ch });
        i++;
      } else {
        throw new Error('Unexpected character: ' + ch);
      }
    }

    // Parser
    let pos = 0;
    function peek() { return tokens[pos]; }
    function consume() { return tokens[pos++]; }

    function parseExpression() {
      let left = parseTerm();
      while (peek() && peek().type === 'operator' && (peek().value === '+' || peek().value === '-')) {
        const op = consume().value;
        const right = parseTerm();
        left = op === '+' ? left + right : left - right;
      }
      return left;
    }

    function parseTerm() {
      let left = parseFactor();
      while (peek() && peek().type === 'operator' && (peek().value === '*' || peek().value === '/' || peek().value === '%')) {
        const op = consume().value;
        const right = parseFactor();
        if (op === '*') left = left * right;
        else if (op === '/') left = left / right;
        else left = left % right;
      }
      return left;
    }

    function parseFactor() {
      // Unary minus
      if (peek() && peek().type === 'operator' && peek().value === '-') {
        consume();
        return -parseFactor();
      }
      // Unary plus
      if (peek() && peek().type === 'operator' && peek().value === '+') {
        consume();
        return parseFactor();
      }
      // Power (right associative)
      let base = parsePrimary();
      if (peek() && peek().type === 'operator' && peek().value === '^') {
        consume();
        const exponent = parseFactor();
        return Math.pow(base, exponent);
      }
      return base;
    }

    function parsePrimary() {
      const token = peek();
      if (!token) throw new Error('Unexpected end of expression');
      if (token.type === 'number') {
        consume();
        return token.value;
      }
      if (token.type === 'constant') {
        consume();
        if (token.value === 'pi') return Math.PI;
        if (token.value === 'e') return Math.E;
      }
      if (token.type === 'function') {
        consume();
        const funcName = token.value;
        if (peek() && peek().type === 'operator' && peek().value === '(') {
          consume();
          const args = [];
          if (peek() && peek().type === 'operator' && peek().value === ')') {
            throw new Error('Function ' + funcName + ' requires at least one argument');
          }
          args.push(parseExpression());
          while (peek() && peek().type === 'operator' && peek().value === ',') {
            consume();
            args.push(parseExpression());
          }
          if (peek() && peek().type === 'operator' && peek().value === ')') {
            consume();
          } else {
            throw new Error('Missing closing parenthesis');
          }
          switch (funcName) {
            case 'sin': return Math.sin(args[0]);
            case 'cos': return Math.cos(args[0]);
            case 'tan': return Math.tan(args[0]);
            case 'asin': return Math.asin(args[0]);
            case 'acos': return Math.acos(args[0]);
            case 'atan': return Math.atan(args[0]);
            case 'sqrt': return Math.sqrt(args[0]);
            case 'log': return Math.log10(args[0]);
            case 'ln': return Math.log(args[0]);
            case 'abs': return Math.abs(args[0]);
            case 'floor': return Math.floor(args[0]);
            case 'ceil': return Math.ceil(args[0]);
            case 'round': return Math.round(args[0]);
            case 'exp': return Math.exp(args[0]);
            case 'pow':
              if (args.length !== 2) throw new Error('pow requires two arguments');
              return Math.pow(args[0], args[1]);
            default:
              throw new Error('Unknown function: ' + funcName);
          }
        } else {
          throw new Error('Function ' + funcName + ' must be followed by parentheses');
        }
      }
      if (token.type === 'operator' && token.value === '(') {
        consume();
        const value = parseExpression();
        if (peek() && peek().type === 'operator' && peek().value === ')') {
          consume();
          return value;
        } else {
          throw new Error('Missing closing parenthesis');
        }
      }
      throw new Error('Unexpected token: ' + token.value);
    }

    const result = parseExpression();
    if (pos < tokens.length) {
      throw new Error('Unexpected token after expression');
    }
    return result;
  }
};