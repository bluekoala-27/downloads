// content.js – dispatches context menu clicks to global handlers
const H = window.PastePlusPlusHelpers;
const features = window.PastePlusPlus;

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'CONTEXT_MENU_CLICKED') {
    const handler = features[message.menuId];
    if (!handler) {
      H.showToast('❌ Unknown feature.');
      return;
    }
    const target = H.findTarget();
    if (!target && message.menuId !== 'glitchKeyboard') {
      H.showToast('❌ No text field found. Click into one first, then right‑click.');
      return;
    }
    handler(target);
  }
});